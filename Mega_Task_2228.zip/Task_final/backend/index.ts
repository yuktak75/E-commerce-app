import "reflect-metadata";
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import fs from 'fs';
import path from 'path';
import rateLimit from 'express-rate-limit';
import cookieParser from 'cookie-parser';
import { AppDataSource } from "./data-source.js";
import type { Request, Response, NextFunction } from 'express';

import authRouter    from './src/routes/auth.routes.js';
import userRouter    from './src/routes/user.routes.js';
import cartRouter    from './src/routes/cart.routes.js';
import productRouter from './src/routes/product.routes.js';
import orderRouter   from './src/routes/order.routes.js';
import { seedDatabase } from './src/seed/seed.js';

const app  = express();
const PORT = 3000;

// Ensure required directories exist 
['ProductImages'].forEach(dir => {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// Rate limiting on auth endpoints 
const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 30,
    message: { message: "Too many requests, please try again later." }
});

// Middleware 
app.use(cors({
    origin: ["http://localhost:4200", "http://localhost:3000"],
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE"]
}));

app.use(morgan('dev'));
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve uploaded product images
app.use('/ProductImages', express.static(path.join(process.cwd(), 'ProductImages')));

// API Routes 
app.use("/api/auth", authLimiter, authRouter);
app.use("/api/user", userRouter);
app.use("/api/cart", cartRouter);
app.use("/api/orders", orderRouter);
app.use("/api/products", productRouter);

// Serve Angular build (after API routes) 
const distPath = path.join(process.cwd(), '../frontend/dist/frontend/browser');
if (fs.existsSync(distPath)) {
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
        res.sendFile(path.join(distPath, 'index.html'));
    });
} else {
    app.get('/', (_req, res) => res.json({ message: "ShopEase API running. Build Angular first for the full app." }));
}

// Global error handler 
app.use((err: any, req: Request, res: Response, _next: NextFunction) => {
    const status  = err.status || 500;
    const message = err.message || "Internal Server Error";
    // Never expose stack traces to client
    res.status(status).json({ success: false, message });
});

AppDataSource.initialize()
    .then(async () => {
        console.log("Database connected");
        await seedDatabase();
        app.listen(PORT, () => {
            console.log(`Server running on http://localhost:${PORT}`);
        });
    })
    .catch((err) => {
        console.error("Database initialization failed:", err);
        process.exit(1);
    });

export { app };