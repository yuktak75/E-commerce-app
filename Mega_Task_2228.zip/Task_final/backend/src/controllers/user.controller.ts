import type { Request, Response } from "express";
import { AppDataSource } from "../../data-source.js";
import { User } from "../entities/user.js";

const userRepo = AppDataSource.getRepository(User);

export class UserController{
    // Get own profile
    static getProfile = async(req:Request, res:Response) => {
        try {
            const sessionUser = (req as any).user;
            const user = await userRepo.findOne({
                where: {id: sessionUser.userId},
                select: ['id', 'name', 'email', 'role']
            });
            if (!user) return res.status(404).json({message: "User not found"});
            return res.json(user);
        } catch(err) {
            return res.status(500).json({message: "Error fetching profile"});
        }
    }

    // Get all customers (admin)
    static getAllCustomers = async(req:Request, res:Response) => {
        try{
            const customers = await userRepo.find({
                where:{role:'Customer'},
                select: ['id', 'name', 'email', 'isLocked', 'role']
            });
            return res.json(customers);
        }
        catch(err){
            return res.status(500).json({message:"Error fetching customers"});
        }
    }

    // Toggle account lock (admin)
    static toggleLock = async(req:Request, res:Response) => {
        try{
            const {id} = req.params;
            const user = await userRepo.findOneBy({id:Number(id)});

            if (!user){
                return res.status(404).json({message:"User not found"});
            }

            user.isLocked = !user.isLocked;
            await userRepo.save(user);

            return res.json({
                message:`User ${user.isLocked ? 'locked' : 'unlocked'} successfully`,
                isLocked: user.isLocked
            });
        }
        catch(err){
            return res.status(500).json({message:"Error toggling lock"});
        }
    }

    // Update own profile
    static updateProfile = async(req:Request, res:Response) => {
        try{
            const {name, email} = req.body;
            const sessionUser = (req as any).user;
            const user = await userRepo.findOneBy({id:sessionUser.userId});

            if(!user){
                return res.status(404).json({message:"User not found"});
            }

            if (email && email !== user.email){
                const emailExists = await userRepo.findOneBy({email});
                if (emailExists){
                    return res.status(400).json({message:"Email already in use"});
                }
                user.email = email;
            }
            if (name) user.name = name;

            await userRepo.save(user);
            return res.json({message:"Profile updated successfully", name: user.name, email: user.email});
        }
        catch(err){
            return res.status(500).json({message:"Error updating profile"});
        }
    }
}