import type { Request, Response } from "express";
import { AppDataSource } from "../../data-source.js";
import { User } from "../entities/user.js";
import bcrypt from 'bcrypt';
import {v4 as uuidv4} from 'uuid';
import { sessionStore } from "../middleware/auth.middleware.js";

const userRepo = AppDataSource.getRepository(User);
const resetCodes = new Map<string, {code:string; expires: number}>();

export class AuthController{
    // Returns currently logged-in user info (used by frontend to restore session)
    static me = async (req:Request, res:Response) => {
        try {
            // Gets sessionUser from middleware
            const sessionUser = (req as any).user;
            // Finds user in repository
            const user = await userRepo.findOne({
                where: { id: sessionUser.userId },
                select: ['id', 'name', 'email', 'role']
            });

            if (!user) return res.status(404).json({ message: "User not found" });
            // Returns user info if user is found
            return res.json({ id: user.id, name: user.name, email: user.email, role: user.role });
        } 
        catch (err) {
            return res.status(500).json({ message: "Error getting session user" });
        }
    }

    // Register new user
    static register = async (req:Request, res:Response) => {
        try{
            // Gets credentials from user to register
            const {name, email, password} = req.body;

            if (!name || !email || !password)
                return res.status(400).json({message: "All fields are required"});
            // Password validation
            if (password.length < 6)
                return res.status(400).json({message: "Password must be at least 6 characters"});

            // Check if user already exists
            const existingUser = await userRepo.findOneBy({email});
            if (existingUser){
                return res.status(400).json({message: "User already registered"});
            }

            // Encrypts password using bcrypt
            const hashedPassword = await bcrypt.hash(password, 10);
            // Creates a new user and saves it into the repository
            const newUser = userRepo.create({name, email, password:hashedPassword});
            await userRepo.save(newUser);
            return res.status(201).json({message:"User registered successfully!"});
        }
        catch(err){
            return res.status(500).json({message: "Error while registering user"});
        }
    }

    // Login user
    static login = async (req:Request, res:Response) => {
        try{
            // Gets credentials from user
            const {email, password} = req.body;

            // Finds the user in database based on email
            const user = await userRepo.findOne({
                where: {email},
                select: ['id', 'password', 'role','isLocked','name']
            });

            // If user doesn't exist or password doesn't match displays error
            if(!user || !(await bcrypt.compare(password, user.password!))){
                return res.status(401).json({message:"Invalid credentials"});
            }

            // Checks if user's account is locked by admin or not
            if(user.isLocked){
                return res.status(403).json({message:"Account is locked by admin! Kindly contact admin."});
            }

            // Generates a session ID
            const sessionId = uuidv4();
            sessionStore.set(sessionId, {userId: user.id!, role: user.role as any});

            // Cookie stores the session_id
            // Session_id is used as a reference to identify user credentials stored in sessionStore (kindof like a user_id or roll_no)
            res.cookie('session_id', sessionId, {
                httpOnly:true,
                secure:false,
                sameSite:'strict',
                maxAge: 3600000
            });

            res.json({
                message: "Login successful",
                name:user.name,
                role: user.role
            });
        }
        catch(err){
            return res.status(500).json({message:"Error occurred while logging in"});
        }
    }

    // Logout
    static logout = async (req:Request, res:Response) => {
        try{
            // Find session_id from cookie
            const sessionId = req.cookies.session_id;
            // Delete that session_id from sessionStore deleting entry of that user
            if (sessionId) sessionStore.delete(sessionId);

            // Clear the cookie of that session_id
            res.clearCookie('session_id', {
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                sameSite: 'strict'
            });

            res.json({message:"Logged out successfully"});
        }
        catch(err){
            return res.status(500).json({message:"Error occurred while logging out"});
        }
    }

    // Forgot Password — request reset code
    static requestReset = async (req:Request, res:Response) => {
        try{
            // Request only email from user
            const {email} = req.body;
            // Find user based on that email from repository
            const user = await userRepo.findOneBy({email});

            if (!user){
                return res.status(404).json({message:"User not found"});
            }

            // Generate a random code (kindof like OTP)
            const code = Math.floor(100000 + Math.random() * 900000).toString();
            // Create a set that stores in reference to that email, the unique code
            resetCodes.set(email, {code, expires: Date.now() + 600000}); // 10 min

            // Per requirements: display code directly on screen (mock flow)
            res.json({message: "Reset code generated", code});
        }
        catch(err){
            return res.status(500).json({message:"Error occurred while requesting password reset"});
        }
    }

    static resetPassword = async (req:Request, res:Response) => {
        try{
            // Request email, unique code and new password to set
            const {email, code, newPassword} = req.body;
            // Check if code matches 
            const record = resetCodes.get(email);

            if (!record || record.code !== code || record.expires < Date.now()){
                return res.status(400).json({message:"Invalid or expired code"});
            }

            // Find the user using email and save new password for that user
            // Clear data for that user from resetCodes
            const user = await userRepo.findOneBy({email});
            if (user){
                user.password = await bcrypt.hash(newPassword, 10);

                await userRepo.save(user);

                resetCodes.delete(email);

                return res.json({message: "Password updated successfully"});
            }
            return res.status(404).json({message:"User not found!"});
        }
        catch(err){
            return res.status(500).json({message:"Error occurred while resetting password"});
        }
    }

    // Change password (authenticated)
    static changePassword = async (req:Request, res:Response) => {
        try{
            // Requests newPassword and currentPassword from user
            const {currentPassword, newPassword} = req.body;
            // Finds the user from middleware
            const sessionUser = (req as any).user;
            const user = await userRepo.findOne({
                where: {id:sessionUser.userId},
                select: ['id', 'password']
            });

            // Checks if current typed password is correct
            if (!user || !(await bcrypt.compare(currentPassword, user.password!))){
                return res.status(400).json({message:"Current password is incorrect"});
            }

            // Encrypts the new password
            user.password = await bcrypt.hash(newPassword, 10);
            await userRepo.save(user);
            return res.json({message:"Password changed successfully"});
        }
        catch(err){
            return res.status(500).json({message:"Error occurred while changing password"});
        }
    }
}