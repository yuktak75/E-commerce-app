import { AppDataSource } from "../../data-source.js";
import { CartItem } from "../entities/cartItem.js";
import { Order } from "../entities/order.js";
import { OrderItem } from "../entities/orderItem.js";
import { Product } from "../entities/product.js";
import type { Request, Response } from "express";

const orderRepo = AppDataSource.getRepository(Order);
const cartRepo  = AppDataSource.getRepository(CartItem);

export class OrderController {

    // Checkout for a user
    static checkout = async (req: Request, res: Response) => {
        const queryRunner = AppDataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();

        try {
            const userId = (req as any).user.userId;
            const { paymentMethod } = req.body;

            if (!paymentMethod) {
                return res.status(400).json({ message: "Payment method is required." });
            }

            // Fetches cart items for that user
            const cartItems = await cartRepo.find({
                where: { user: { id: userId } },
                relations: ["product"]
            });

            if (cartItems.length === 0) {
                return res.status(400).json({ message: "Your cart is empty!" });
            }

            // Validates stock and compute total
            let totalAmt = 0;
            for (const item of cartItems) {
                if (!item.product) {
                    throw new Error("A product in your cart no longer exists.");
                }
                if (item.product.stockQuantity < item.quantity) {
                    throw new Error(`"${item.product.name}" has only ${item.product.stockQuantity} units in stock.`);
                }
                totalAmt += Number(item.product.price) * item.quantity;
            }

            // Save order header for order-detail
            const newOrder = queryRunner.manager.create(Order, {
                user: { id: userId } as any,
                paymentMethod,
                totalAmount: totalAmt
            });
            const savedOrder = await queryRunner.manager.save(newOrder);

            // Save order items and decrement stock
            for (const item of cartItems) {
                const orderItem = queryRunner.manager.create(OrderItem, {
                    productName: item.product.name,
                    priceAtPurchase: item.product.price,
                    quantity: item.quantity,
                    order: savedOrder
                });
                await queryRunner.manager.save(orderItem);

                // Decrement stock using TypeORM (no require())
                await queryRunner.manager.decrement(
                    Product,
                    { id: item.product.id },
                    "stockQuantity",
                    item.quantity
                );
            }

            // Clear cart
            await queryRunner.manager.delete(CartItem, { user: { id: userId } });

            await queryRunner.commitTransaction();

            return res.status(201).json({
                message: "Order placed successfully",
                orderId: savedOrder.id,
                totalAmount: totalAmt,
                paymentMethod: savedOrder.paymentMethod
            });

        } catch (err: any) {
            await queryRunner.rollbackTransaction();
            return res.status(400).json({ message: err.message || "Checkout failed." });
        } finally {
            await queryRunner.release();
        }
    };

    static getMyOrders = async (req: Request, res: Response) => {
        try {
            // Fetches users and finds his orders
            const userId = (req as any).user.userId;
            const orders = await orderRepo.find({
                where: { user: { id: userId } },
                relations: ["items"],
                order: { orderDate: "DESC" }
            });
            return res.json(orders);
        } 
        catch (err) {
            return res.status(500).json({ message: "Error fetching your orders." });
        }
    };

    static getOrderDetails = async (req: Request, res: Response) => {
        try {
            const { id } = req.params;
            const userId = (req as any).user.userId;
            const userRole = (req as any).user.role;

            // Finds orders for that user
            const order = await orderRepo.findOne({
                where: { id: Number(id) },
                relations: ["items", "user"]
            });

            if (!order) {
                return res.status(404).json({ message: "Order not found." });
            }

            // Customers can only see their own orders; Admin can see all
            if (order.user?.id !== userId && userRole !== "Admin") {
                return res.status(403).json({ message: "Access denied." });
            }

            return res.json(order);
        } 
        catch (err) {
            return res.status(500).json({ message: "Error fetching order details." });
        }
    };

    static getAllOrders = async (req: Request, res: Response) => {
        try {
            // Gets all orders of all customers
            const orders = await orderRepo.find({
                relations: ["items", "user"],
                order: { orderDate: "DESC" }
            });
            return res.json(orders);
        } 
        catch (err) {
            return res.status(500).json({ message: "Error fetching all orders." });
        }
    };
}