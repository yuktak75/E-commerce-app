import type { Request, Response } from "express";
import { AppDataSource } from "../../data-source.js"
import { CartItem } from "../entities/cartItem.js"
import { Product } from "../entities/product.js";

const cartRepo = AppDataSource.getRepository(CartItem);
const productRepo = AppDataSource.getRepository(Product);

export class CartController{

    // Get cart for that user
    static getCart = async(req:Request, res:Response) => {
        try{
            // Fetches user id of user
            const userId = (req as any).user.userId;

            // Finds the cart and prints it
            const cart = await cartRepo.find({
                where: {user: {id:userId}},
                relations: ['product']
            });
            res.json(cart);
        }
        catch(err){
            return res.status(500).json({message:"Error occured while getting cart: ", err});
        }
    }

    // Adds item to cart
    static addToCart = async(req:Request, res:Response) => {
        try{
            const {productId, quantity} = req.body;
            const userId = (req as any).user.userId;

            if (!productId || !quantity || quantity < 1){
                return res.status(400).json({message:"Valid productId and quantity (min 1) is required"});
            }

            // Finds the product
            const product = await productRepo.findOneBy({id:productId});

            // Checks if product exists
            if(!product){
                return res.status(404).json({message:"Product not found"});
            }

            // Find if the item exists in user's cart 
            let item = await cartRepo.findOne({
                where: {
                    user: {id:userId}, 
                    product: {id:productId}
                }
            });

            const existingQty = item ? item.quantity : 0;
            const newTotalQty = existingQty + quantity;

            if (product.stockQuantity! < newTotalQty){
                return res.status(400).json({message: `Not enough stock. Only ${product.stockQuantity} available`});
            }

            // If present, increase its quantity
            if (item){ 
                item.quantity += quantity;
            }
            else{

                // If not present create one
                item = cartRepo.create({
                    user: {id:userId} as any,
                    product: {id:productId} as any,
                    quantity
                });
            }

            // Save updated cart
            await cartRepo.save(item);
            return res.json({message: "Cart updated successfully"});
        }
        catch(err){
            return res.status(500).json({message:"Error occured while adding to cart: ", err});
        }
    }

    static updateQuantity = async (req:Request, res:Response) => {
        try{
            const {id} = req.params;
            const {quantity} = req.body;
            const userId = (req as any).user.userId;

            // Check if quantity is valid
            if (!quantity || quantity < 1){
                return res.status(400).json({message: "Quantity must be atleast 1"});
            }

            // Find item in repository
            const item = await cartRepo.findOne({
                where: {id: Number(id), user: {id: userId}},
                relations: ['product']
            });

            if (!item){
                return res.status(404).json({message: "Cart Item not found!"});
            }

            // Check if item in stock
            if (item.product.stockQuantity! < quantity){
                return res.status(400).json({message: `Not enough stock. Only ${item.product.stockQuantity} available`});
            }

            // Update quantity of item
            item.quantity = quantity;
            await cartRepo.save(item);
            return res.json({message: "Cart quantity updated successfully"});
        }
        catch(err){
            return res.status(500).json({message:"Error occured while updating cart quantity: ", err});
        }
    }

    // Removes item from cart
    static removeItem = async (req:Request, res:Response) => {
        try{
            // This id is id of cart item
            const {id} = req.params;
            const userId = (req as any).user.userId;

            // Deletes the item only of that user in cart
            const deleteRes = await cartRepo.delete({
                id: Number(id),
                user: {id:userId}
            });

            // If none of the rows are affected => the item doesn't exist in the cart
            if (deleteRes.affected === 0){
                return res.status(404).json({message:"Item not found in cart!"});
            }

            res.json({message:"Item removed"});
        }
        catch(err){
            return res.status(500).json({message:"Error occured while removing item from cart: ", err});
        }
    }

    // Clear complete cart
    static clearCart = async(req:Request, res:Response) => {
        try{
            const userId = (req as any).user.userId;
            // Delete cart for that user
            await cartRepo.delete({user:{id:userId}});
            return res.json({message:"Cart cleared successfully!"});
        }
        catch(err){
            return res.status(500).json({message:"Error occured while clearing cart: ", err});
        }
    }
}