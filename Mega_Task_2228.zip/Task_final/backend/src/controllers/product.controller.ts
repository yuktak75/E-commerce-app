import type { Request, Response } from "express";
import { AppDataSource } from "../../data-source.js";
import { Product } from "../entities/product.js";
import { Category } from "../entities/category.js";
import { SubCategory } from "../entities/subcat.js";
import { Type } from "../entities/type.js";
import { Between, LessThanOrEqual, Like, MoreThanOrEqual, type FindOptionsOrder, type FindOptionsWhere } from "typeorm";

const productRepo = AppDataSource.getRepository(Product);
const typeRepo = AppDataSource.getRepository(Type);

export class ProductController{

    // 4-level hierarchy for dropdowns
    // Type -> Category -> SubCategory -> Product
    static getTaxonomy = async (req:Request, res:Response) => {
        try {
            // Find the types
            const types = await typeRepo.find({
                relations: ['categories', 'categories.subCategories']
            });
            return res.json(types);
        } catch(err) {
            return res.status(500).json({message: "Error fetching taxonomy"});
        }
    }

    static getProducts = async (req:Request, res:Response) => {
        try{
            const {
                search, subCategoryId, categoryId, typeId,
                minPrice, maxPrice, sortBy,
                page = "1", limit = "12"
            } = req.query;

            const pageNum = Math.max(1, parseInt(page as string));
            const limitNum = Math.min(50, Math.max(1, parseInt(limit as string)));
            const skip = (pageNum - 1) * limitNum;

            // Build where conditions — supports cross-taxonomy keyword search
            const whereConditions: FindOptionsWhere<Product>[] = [];

            if (search) {
                // Search in both name and description across all taxonomy
                const base: FindOptionsWhere<Product> = {};
                if (subCategoryId){ 
                    base.subCategory = {id: Number(subCategoryId)};
                }
                if (categoryId){ 
                    base.subCategory = {...(base.subCategory as any), category: {id: Number(categoryId)}};
                }
                if (typeId){ 
                    base.subCategory = {...(base.subCategory as any), category: {type: {id: Number(typeId)}}};
                }

                if (minPrice && maxPrice){ 
                    base.price = Between(Number(minPrice), Number(maxPrice));
                }
                else if (minPrice){ 
                    base.price = MoreThanOrEqual(Number(minPrice));
                }
                else if (maxPrice){ 
                    base.price = LessThanOrEqual(Number(maxPrice));
                }

                whereConditions.push({ ...base, name: Like(`%${search}%`) });
                whereConditions.push({ ...base, description: Like(`%${search}%`) });
            } 
            else {
                const base: FindOptionsWhere<Product> = {};
                if (subCategoryId){ 
                    base.subCategory = {id: Number(subCategoryId)};
                }
                if (categoryId){ 
                    base.subCategory = {...(base.subCategory as any), category: {id: Number(categoryId)}};
                }
                if (typeId){ 
                    base.subCategory = {...(base.subCategory as any), category: {type: {id: Number(typeId)}}};
                }
                if (minPrice && maxPrice){ 
                    base.price = Between(Number(minPrice), Number(maxPrice));
                }
                else if (minPrice){ 
                    base.price = MoreThanOrEqual(Number(minPrice));
                }
                else if (maxPrice){ 
                    base.price = LessThanOrEqual(Number(maxPrice));
                }
                whereConditions.push(base);
            }

            const orderOptions: FindOptionsOrder<Product> = {};
            if (sortBy === 'price_asc'){ 
                orderOptions.price = 'ASC';
            }
            else if (sortBy === 'price_desc'){ 
                orderOptions.price = 'DESC';
            }
            else{ 
                orderOptions.id = 'DESC';
            }

            const [products, total] = await productRepo.findAndCount({
                where: whereConditions,
                relations: ['subCategory', 'subCategory.category', 'subCategory.category.type'],
                order: orderOptions,
                skip,
                take: limitNum
            });

            return res.json({
                products,
                total,
                page: pageNum,
                pages: Math.ceil(total / limitNum)
            });
        }
        catch(err){
            return res.status(500).json({message: "Error fetching products"});
        }
    }

    static getProductById = async (req:Request, res:Response) => {
        try{
            const {id} = req.params;
            // Finds product through id
            const product = await productRepo.findOne({
                where: {id:Number(id)},
                relations:['subCategory', 'subCategory.category', 'subCategory.category.type']
            });

            if (!product){
                return res.status(404).json({message:"Product not found"});
            }
            return res.json(product);
        }
        catch(err){
            return res.status(500).json({message:"Error fetching product"});
        }
    }

    static addProduct = async (req:Request, res:Response) => {
        try{
            const {name, description, price, stockQuantity, subCategoryId} = req.body;

            // Validation of fields
            if(!name || !description || price === undefined || stockQuantity === undefined || !subCategoryId){
                return res.status(400).json({message: "All fields are required"});
            }
            if (Number(price) <= 0){
                return res.status(400).json({message: "Price must be greater than 0"});
            }
            if (Number(stockQuantity) < 0){
                return res.status(400).json({message: "Stock quantity cannot be negative"});
            }

            // Registers new product
            const newProduct = productRepo.create({
                name: name.trim(),
                description: description.trim(),
                price: Number(price),
                stockQuantity: Number(stockQuantity),
                subCategory: {id: Number(subCategoryId)} as any
            });

            await productRepo.save(newProduct);

            return res.status(201).json({message: "Product added successfully", product: newProduct});
        }
        catch(err){
            return res.status(400).json({message:"Failed to add product"});
        }
    }

    static updateProduct = async (req:Request, res:Response) => {
        try {
            const {id} = req.params;
            const {name, description, price, stockQuantity, subCategoryId} = req.body;

            const product = await productRepo.findOneBy({id: Number(id)});
            if (!product) return res.status(404).json({message: "Product not found"});

            if (name){ 
                product.name = name.trim();
            }
            if (description){ 
                product.description = description.trim();
            }
            if (price !== undefined) {
                if (Number(price) <= 0) return res.status(400).json({message: "Price must be > 0"});
                product.price = Number(price);
            }
            if (stockQuantity !== undefined) {
                if (Number(stockQuantity) < 0) return res.status(400).json({message: "Stock cannot be negative"});
                product.stockQuantity = Number(stockQuantity);
            }
            if (subCategoryId){ 
                product.subCategory = {id: Number(subCategoryId)} as any;
            }
            if ((req as any).file){ 
                product.imagePath = `ProductImages/${(req as any).file.filename}`;
            }

            await productRepo.save(product);

            return res.json({message: "Product updated successfully", product});
        } 
        catch(err) {
            return res.status(500).json({message: "Error updating product"});
        }
    }

    static deleteProduct = async (req:Request, res:Response) => {
        try{
            const {id} = req.params;
            // Deletes product by id
            const result = await productRepo.delete(Number(id));
            // If nothing is affected => then the product wasn't there at all
            if (result.affected === 0){ 
                return res.status(404).json({message: "Product not found"});
            }

            return res.json({message:"Product deleted successfully"});
        }
        catch(err){
            return res.status(500).json({message:"Error deleting product"});
        }
    }
}