import { Router } from "express";
import { CartController } from "../controllers/cart.controller.js";
import { authenticate } from "../middleware/auth.middleware.js";

const cartRouter = Router();

cartRouter.get("/", authenticate, CartController.getCart);
cartRouter.post("/", authenticate, CartController.addToCart);

cartRouter.put("/:id", authenticate, CartController.updateQuantity);

cartRouter.delete("/:id", authenticate, CartController.removeItem);
cartRouter.delete("/clear/all", authenticate, CartController.clearCart);

export default cartRouter;