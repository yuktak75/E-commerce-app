import { Router } from "express";
import { ProductController } from "../controllers/product.controller.js";
import { authenticate, authorize } from "../middleware/auth.middleware.js";
import { upload } from "../middleware/upload.middleware.js";

const productRouter = Router();

// Public — /taxonomy MUST be before /:id
productRouter.get("/taxonomy", ProductController.getTaxonomy);
productRouter.get("/", ProductController.getProducts);
productRouter.get("/:id", ProductController.getProductById);

// Admin only
productRouter.post("/", authenticate, authorize(['Admin']), upload.single('image'), ProductController.addProduct);
productRouter.put("/:id", authenticate, authorize(['Admin']), upload.single('image'), ProductController.updateProduct);
productRouter.delete("/:id", authenticate, authorize(['Admin']), ProductController.deleteProduct);

export default productRouter;