import { Router } from "express";
import { AuthController } from "../controllers/auth.controller.js";
import { authenticate } from "../middleware/auth.middleware.js";

const authRouter = Router();

authRouter.post("/register", AuthController.register);
authRouter.post("/login", AuthController.login);

authRouter.post("/forgot-password", AuthController.requestReset);
authRouter.post("/reset-password", AuthController.resetPassword);

authRouter.get("/me", authenticate, AuthController.me);
authRouter.patch("/change-password", authenticate, AuthController.changePassword);
authRouter.post("/logout", authenticate, AuthController.logout);

export default authRouter;