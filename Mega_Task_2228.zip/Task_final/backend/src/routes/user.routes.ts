import { Router } from "express";
import { authenticate, authorize } from "../middleware/auth.middleware.js";
import { UserController } from "../controllers/user.controller.js";

const userRouter = Router();

userRouter.get("/", authenticate, authorize(['Admin']), UserController.getAllCustomers);
userRouter.patch("/:id/toggle-lock", authenticate, authorize(['Admin']), UserController.toggleLock);

userRouter.get("/profile", authenticate, UserController.getProfile);
userRouter.put("/profile", authenticate, UserController.updateProfile);

export default userRouter;