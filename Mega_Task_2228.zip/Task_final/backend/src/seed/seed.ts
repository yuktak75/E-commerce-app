import { AppDataSource } from "../../data-source.js";
import { Category } from "../entities/category.js";
import { Product } from "../entities/product.js";
import { SubCategory } from "../entities/subcat.js";
import { Type } from "../entities/type.js";
import { User } from "../entities/user.js";
import bcrypt from "bcrypt";

export const seedDatabase = async () => {
    try {
        console.log("🌱 Seeding started...");

        const typeRepo = AppDataSource.getRepository(Type);
        const catRepo  = AppDataSource.getRepository(Category);
        const subRepo  = AppDataSource.getRepository(SubCategory);
        const prodRepo = AppDataSource.getRepository(Product);
        const userRepo = AppDataSource.getRepository(User);

        // Only seed if DB is empty
        const existingTypes = await typeRepo.count();
        if (existingTypes > 0) {
            console.log("✅ Database already seeded — skipping.");
            return;
        }

        // Hash password: "Password123!"
        const hashedPw = await bcrypt.hash("Password123!", 10);

        // ── TYPES ──────────────────────────────────────────────
        const electronics = await typeRepo.save(typeRepo.create({ name: "Electronics" }));
        const stationery  = await typeRepo.save(typeRepo.create({ name: "Stationery" }));
        const furniture   = await typeRepo.save(typeRepo.create({ name: "Furniture" }));
        const clothing    = await typeRepo.save(typeRepo.create({ name: "Clothing" }));

        // ── CATEGORIES ─────────────────────────────────────────
        const computers = await catRepo.save(catRepo.create({ name: "Computer Peripherals", type: electronics }));
        const mobiles   = await catRepo.save(catRepo.create({ name: "Mobile Phones",        type: electronics }));
        const kids      = await catRepo.save(catRepo.create({ name: "Kids",                 type: stationery }));
        const office    = await catRepo.save(catRepo.create({ name: "Office",               type: stationery }));
        const living    = await catRepo.save(catRepo.create({ name: "Living Room",          type: furniture }));
        const bedroom   = await catRepo.save(catRepo.create({ name: "Bedroom",              type: furniture }));
        const menswear  = await catRepo.save(catRepo.create({ name: "Menswear",             type: clothing }));

        // ── SUB-CATEGORIES ─────────────────────────────────────
        const keyboards   = await subRepo.save(subRepo.create({ name: "Keyboards",   category: computers }));
        const mouse        = await subRepo.save(subRepo.create({ name: "Mouse",        category: computers }));
        const smartphones = await subRepo.save(subRepo.create({ name: "Smartphones", category: mobiles }));
        const textbooks   = await subRepo.save(subRepo.create({ name: "Textbooks",   category: kids }));
        const notepads    = await subRepo.save(subRepo.create({ name: "Notepads",    category: office }));
        const sofas       = await subRepo.save(subRepo.create({ name: "Sofas",       category: living }));
        const tables      = await subRepo.save(subRepo.create({ name: "Tables",      category: living }));
        const beds        = await subRepo.save(subRepo.create({ name: "Beds",        category: bedroom }));
        const tshirts     = await subRepo.save(subRepo.create({ name: "T-Shirts",    category: menswear }));

        // ── PRODUCTS (imagePath stored WITHOUT leading slash) ──
        const ph = 'ProductImages/placeholder.jpg'; // shared placeholder
        await prodRepo.save([
            { 
                name: "Anker Multimedia Keyboard",   
                description: "Full-size wireless keyboard with quiet keys and long battery life.", 
                price: 45.99,  stockQuantity: 80,  
                imagePath: 'ProductImages/anker-keyboard.jpg', 
                subCategory: keyboards  
            },
            { 
                name: "Mechanical Gaming Keyboard",   
                description: "RGB backlit mechanical keyboard with blue switches.",               
                price: 89.99,  
                stockQuantity: 35,  
                imagePath: 'ProductImages/gaming-keyboard.webp', 
                subCategory: keyboards  
            },
            { 
                name: "Logitech MX Master 3",         
                description: "Advanced wireless mouse with ultra-fast scroll wheel.",             
                price: 99.99,  
                stockQuantity: 50,  
                imagePath: 'ProductImages/mouse.webp', 
                subCategory: mouse       
            },
            { 
                name: "Apple Magic Mouse",            
                description: "Multi-touch surface, smooth scroll, rechargeable.",                
                price: 79.99,  
                stockQuantity: 25,  
                imagePath: 'ProductImages/apple-mouse.jpg', 
                subCategory: mouse       
            },
            { 
                name: "Samsung Galaxy S24",           
                description: "6.2-inch display, 50MP camera, 5000mAh battery.",                 
                price: 799.99, 
                stockQuantity: 20,  
                imagePath: 'ProductImages/samsung-phone.webp', 
                subCategory: smartphones 
            },
            { 
                name: "iPhone 15 Pro",                
                description: "Titanium design, A17 Pro chip, 48MP camera system.",               
                price: 999.99, 
                stockQuantity: 15,  
                imagePath: 'ProductImages/iphone.jpg', 
                subCategory: smartphones 
            },
            { 
                name: "Multiplication Table Book",    
                description: "Colourful illustrated maths textbook for children aged 6-10.",    
                price: 12.99,  
                stockQuantity: 200, 
                imagePath: 'ProductImages/multiplication-book.jpg', 
                subCategory: textbooks  
            },
            { 
                name: "Science Activity Workbook",    
                description: "Interactive experiments and activities for kids.",                 
                price: 9.99,   
                stockQuantity: 150, 
                imagePath: 'ProductImages/science-workbook.jpg', 
                subCategory: textbooks  
            },
            { 
                name: "A4 Ruled Notepad (50 sheets)", 
                description: "Quality lined paper, micro-perforated for clean tear-off.",       
                price: 3.49,   
                stockQuantity: 500, 
                imagePath: 'ProductImages/notepad.webp', 
                subCategory: notepads   
            },
            { 
                name: "Wooden Coffee Table",          
                description: "Solid oak with modern minimalist legs, seats 4.",                 
                price: 249.99, 
                stockQuantity: 12,  
                imagePath: 'ProductImages/wooden-coffee-table.jpg', 
                subCategory: tables     
            },
            { 
                name: "Glass Side Table",             
                description: "Tempered glass top with chrome frame, ideal beside sofa.",        
                price: 89.99,  
                stockQuantity: 30,  
                imagePath: 'ProductImages/glass-side-table.jpg', 
                subCategory: tables     
            },
            { 
                name: "3-Seater Fabric Sofa",         
                description: "Comfortable family sofa in charcoal grey fabric.",                
                price: 699.99, 
                stockQuantity: 8,   
                imagePath: 'ProductImages/fabric-sofa.webp', 
                subCategory: sofas      
            },
            { 
                name: "King Size Wooden Bed Frame",   
                description: "Solid pine frame, slats included, fits 180×200 mattress.",        
                price: 349.99, 
                stockQuantity: 10,  
                imagePath: 'ProductImages/wooden-bed-frame.jpg', 
                subCategory: beds       
            },
            { 
                name: "Classic White T-Shirt",        
                description: "100% cotton, regular fit, pre-shrunk.",                           
                price: 14.99,  
                stockQuantity: 300, 
                imagePath: 'ProductImages/white-tshirt.webp', 
                subCategory: tshirts    
            },
        ]);

        // ── USERS ──────────────────────────────────────────────
        await userRepo.save([
            { name: "Admin User", email: "admin@shop.com",    password: hashedPw, role: "Admin",    isLocked: false },
            { name: "John Doe",   email: "customer@test.com", password: hashedPw, role: "Customer", isLocked: false },
        ]);

        console.log("✅ Seeding complete!");
        console.log("   Admin login:    admin@shop.com    / Password123!");
        console.log("   Customer login: customer@test.com / Password123!");

    } catch (error) {
        console.error("❌ Seeding failed:", error);
    }
};