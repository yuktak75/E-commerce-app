import multer from "multer";
import path from "path";
import fs from "fs";

// Tells multer to store files on disk not memory
const storage = multer.diskStorage({
    destination: (_req, _file, cb) => {
        cb(null, 'ProductImages');
    },
    // Generates a unique file name for the file uploaded
    filename: (_req, file, cb) => {
        const unique = Date.now() + '-' + Math.round(Math.random() * 1e9);
        cb(null, unique + path.extname(file.originalname));
    }
});

// Only the files of these types are allowed
// Checks file extension and MIME type
const fileFilter = (_req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    const allowed = /jpeg|jpg|png|gif|webp/;
    const valid = allowed.test(path.extname(file.originalname).toLowerCase())
               && allowed.test(file.mimetype);
    if (valid) cb(null, true);
    else cb(new Error('Only image files are allowed'));
};

// Max upload size -> 5 MB
export const upload = multer({storage, limits: { fileSize: 5 * 1024 * 1024 }, fileFilter});