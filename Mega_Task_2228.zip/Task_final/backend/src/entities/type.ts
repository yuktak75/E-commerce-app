import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Type{
    @PrimaryGeneratedColumn()
    id!:number;

    @Column({type:"varchar",unique:true})
    name!:string;

    // Many categories can have 1 type
    @OneToMany("Category", (category:any) => category.type)
    categories!:any[];
}