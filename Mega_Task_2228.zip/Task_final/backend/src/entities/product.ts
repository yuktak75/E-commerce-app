import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Product{
    @PrimaryGeneratedColumn()
    id!:number;

    @Column({type:"varchar"})
    name!:string;

    @Column('text')
    description!:string;

    @Column({type:'decimal', precision:10, scale:2})
    price!:number;

    @Column('int')
    stockQuantity!:number;

    @Column({type:"varchar", nullable:true})
    imagePath!:string;

    // Many products can have 1 subcategory
    @ManyToOne("SubCategory", (sub:any) => sub.products)
    subCategory!:any;
}