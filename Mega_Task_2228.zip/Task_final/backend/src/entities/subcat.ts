import { Column, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class SubCategory{
    @PrimaryGeneratedColumn()
    id!:number;

    @Column({type:'varchar', length:150})
    name!:string;

    // Many subcategories belong to 1 category
    @ManyToOne("Category", (cat:any) => cat.subCategories)
    category!:any;

    // 1 subcategory can have many products
    @OneToMany("Product", (prod:any) => prod.subCategory)
    products!:any[];
}