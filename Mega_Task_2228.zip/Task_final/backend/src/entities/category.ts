import { Column, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Category{
    @PrimaryGeneratedColumn()
    id!:number;

    @Column({type:'varchar', length:150})
    name!:string;

    // Many categories belong to one type
    @ManyToOne("Type", (type:any) => type.categories)
    type!:any;

    // 1 category has many subcategories
    @OneToMany("SubCategory", (sub:any) => sub.category)
    subCategories!:any[];
}