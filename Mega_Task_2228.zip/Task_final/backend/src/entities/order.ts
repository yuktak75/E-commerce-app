import { Column, CreateDateColumn, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class Order{
    @PrimaryGeneratedColumn()
    id!:number;

    @CreateDateColumn()
    orderDate!:Date;

    @Column({ type:"varchar", default: "Cash"})
    paymentMethod!:"Cash" | "Debit Card" | "Credit Card" | "Bank Transfer";

    @Column({type: 'decimal', precision: 10, scale:2})
    totalAmount!:number;

    // Many orders belong to one user
    @ManyToOne("User", (user:any) => user.orders)
    user!:any;

    // 1 Order can have many orderItems => 1 order can have many items
    // Each product is 1 orderItem
    @OneToMany("OrderItem", (orderitem:any) => orderitem.order, {cascade:true})
    items!:any[];
}

