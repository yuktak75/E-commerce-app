import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";

@Entity()
export class OrderItem{
    @PrimaryGeneratedColumn()
    id!:number;

    @Column({type:"varchar"})
    productName!:string;

    @Column({type:'decimal', precision:10, scale:2})
    priceAtPurchase!:number;

    @Column('int')
    quantity!:number;

    // Many orderItems belong to 1 order
    @ManyToOne("Order", (order:any) => order.items)
    order!:any;
}