/**
 * This file sets up connection between application and database
 * It is a configuration file for TypeORM
 * ORM -> Object Relational Mapper between JS and TS
 */

import {DataSource} from 'typeorm';
import { User } from './src/entities/user.js';
import { Product } from './src/entities/product.js';
import { Category } from './src/entities/category.js';
import { SubCategory } from './src/entities/subcat.js';
import { Type } from './src/entities/type.js';
import { Order } from './src/entities/order.js';
import { OrderItem } from './src/entities/orderItem.js';
import { CartItem } from './src/entities/cartItem.js';

export const AppDataSource = new DataSource({
    type: "better-sqlite3",
    database: "ecommerce.db",
    synchronize: true,
    logging: false,
    entities: [User, Product, Category, SubCategory, Type, Order, OrderItem, CartItem]
});