import { Component } from '@angular/core';
import { CartService } from '../../services/cart.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-cart',
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent {
  cartItems: any[] = [];
  updating: number | null = null;
 
  constructor(private cartService: CartService) {}
 
  ngOnInit() {
    this.cartService.loadCart();
    this.cartService.cartItems$.subscribe(items => this.cartItems = items);
  }
 
  getImageUrl(imagePath: string) {
    if (!imagePath) return 'backend/ProductImages/placeholder.jpg';
    return `http://localhost:3000/${imagePath}`;
  }
 
  get total() {
    return this.cartItems.reduce((sum, i) => sum + (Number(i.product?.price) * i.quantity), 0);
  }
 
  updateQty(item: any, delta: number) {
    const newQty = item.quantity + delta;
    if (newQty < 1) return;
    this.updating = item.id;
    this.cartService.updateQuantity(item.id, newQty).subscribe({
      next: () => this.updating = null,
      error: () => this.updating = null
    });
  }
 
  remove(item: any) {
    this.cartService.removeFromCart(item.id).subscribe();
  }
}
