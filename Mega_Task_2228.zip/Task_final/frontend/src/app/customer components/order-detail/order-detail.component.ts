import { Component } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { UserService } from '../../services/user.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-order-detail',
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './order-detail.component.html',
  styleUrl: './order-detail.component.css'
})
export class OrderDetailComponent {
  order: any = null;
  loading = true;
  error = '';
 
  constructor(private route: ActivatedRoute, private userService: UserService) {}
 
  ngOnInit() {
    const id = +this.route.snapshot.paramMap.get('id')!;
    this.userService.getOrderDetails(id).subscribe({
      next: (o) => { this.order = o; this.loading = false; },
      error: (err) => { this.error = err.message; this.loading = false; }
    });
  }
}
