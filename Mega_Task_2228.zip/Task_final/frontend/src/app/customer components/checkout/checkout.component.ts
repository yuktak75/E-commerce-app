import { Component } from '@angular/core';
import { CartService } from '../../services/cart.service';
import { UserService } from '../../services/user.service';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-checkout',
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css'
})
export class CheckoutComponent {
  // checkout.component.ts
cartItems: any[] = [];
  paymentMethods = ['Credit Card', 'Debit Card', 'Cash on Delivery', 'Bank Transfer'];
  selectedMethod = '';
  error = '';
  loading = false;
  orderResult: any = null;
 
  constructor(
    private cartService: CartService,
    private userService: UserService,
    private router: Router
  ) {}
 
  ngOnInit() {
    this.cartService.loadCart();
    this.cartService.cartItems$.subscribe(items => {
      this.cartItems = items;
      if (items.length === 0 && !this.orderResult) {
        // Don't redirect immediately — cart clears on success too
      }
    });
  }
 
  get total() {
    return this.cartItems.reduce((sum, i) => sum + (Number(i.product?.price) * i.quantity), 0);
  }
 
  getImageUrl(imagePath: string) {
    if (!imagePath) return 'backend/ProductImages/placeholder.jpg';
    return `http://localhost:3000/${imagePath}`;
  }
 
  placeOrder() {
    if (!this.selectedMethod) { this.error = 'Please select a payment method.'; return; }
    this.loading = true;
    this.error = '';
    this.userService.checkout(this.selectedMethod).subscribe({
      next: (res: any) => {
        this.loading = false;
        this.orderResult = res;
        this.cartService.clearLocalCart();
      },
      error: (err) => { this.loading = false; this.error = err.message || 'Checkout failed.'; }
    });
  }
}
