import { Component } from '@angular/core';
import { UserService } from '../../services/user.service';
import { AuthService } from '../../services/auth.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-profile',
  imports: [FormsModule, CommonModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.css'
})
export class ProfileComponent {
  name = '';
  email = '';
  profileMsg = '';
  profileError = '';
  profileLoading = false;
 
  // Change password fields
  currentPassword = '';
  newPassword = '';
  confirmPassword = '';
  pwMsg = '';
  pwError = '';
  pwLoading = false;
 
  constructor(private userService: UserService, private authService: AuthService) {}
 
  ngOnInit() {
    this.userService.getProfile().subscribe({
      next: (user) => { this.name = user.name; this.email = user.email; },
      error: () => {}
    });
  }
 
  updateProfile() {
    if (!this.name || !this.email) { this.profileError = 'Name and email are required.'; return; }
    this.profileLoading = true;
    this.profileError = '';
    this.profileMsg = '';
    this.userService.updateProfile({ name: this.name, email: this.email }).subscribe({
      next: (res: any) => {
        this.profileLoading = false;
        this.profileMsg = 'Profile updated successfully!';
        // Update navbar user name
        const current = this.authService.currentUserValue;
        if (current) {
          this.authService['currentUserSubject'].next({ ...current, name: res.name, email: res.email });
        }
      },
      error: (err:any) => { this.profileLoading = false; this.profileError = err.message || 'Update failed.'; }
    });
  }
 
  changePassword() {
    this.pwError = '';
    this.pwMsg = '';
    if (!this.currentPassword || !this.newPassword || !this.confirmPassword) {
      this.pwError = 'All password fields are required.'; return;
    }
    if (this.newPassword.length < 6) { this.pwError = 'New password must be at least 6 characters.'; return; }
    if (this.newPassword !== this.confirmPassword) { this.pwError = 'New passwords do not match.'; return; }
    this.pwLoading = true;
    this.authService.changePassword(this.currentPassword, this.newPassword).subscribe({
      next: () => {
        this.pwLoading = false;
        this.pwMsg = 'Password changed successfully!';
        this.currentPassword = '';
        this.newPassword = '';
        this.confirmPassword = '';
      },
      error: (err) => { this.pwLoading = false; this.pwError = err.message || 'Password change failed.'; }
    });
  }
}
