import { Routes } from '@angular/router';
import { authGuard } from './guards/auth.guard';
import { adminGuard } from './guards/admin.guard';
import { guestGuard } from './guards/guest.guard';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },

  { path: 'home',
    loadComponent: () => import('./home/home.component').then(m => m.HomeComponent) },

  { path: 'products',
    loadComponent: () => import('./product-list/product-list.component').then(m => m.ProductListComponent) },

  { path: 'products/:id',
    loadComponent: () => import('./product-detail/product-detail.component').then(m => m.ProductDetailComponent) },

  { path: 'login', canActivate: [guestGuard],
    loadComponent: () => import('./login/login.component').then(m => m.LoginComponent) },

  { path: 'register', canActivate: [guestGuard],
    loadComponent: () => import('./register/register.component').then(m => m.RegisterComponent) },

  { path: 'forgot-password',
    loadComponent: () => import('./forgot-password/forgot-password.component').then(m => m.ForgotPasswordComponent) },

  { path: 'cart', canActivate: [authGuard],
    loadComponent: () => import('./customer components/cart/cart.component').then(m => m.CartComponent) },

  { path: 'checkout', canActivate: [authGuard],
    loadComponent: () => import('./customer components/checkout/checkout.component').then(m => m.CheckoutComponent) },

  { path: 'orders', canActivate: [authGuard],
    loadComponent: () => import('./customer components/order-history/order-history.component').then(m => m.OrderHistoryComponent) },

  { path: 'orders/:id', canActivate: [authGuard],
    loadComponent: () => import('./customer components/order-detail/order-detail.component').then(m => m.OrderDetailComponent) },

  { path: 'profile', canActivate: [authGuard],
    loadComponent: () => import('./customer components/profile/profile.component').then(m => m.ProfileComponent) },

  {
    path: 'admin',
    canActivate: [authGuard, adminGuard],
    loadComponent: () => import('./admin components/admin-dashboard/admin-dashboard.component').then(m => m.AdminDashboardComponent),
    children: [
      { path: '', redirectTo: 'products', pathMatch: 'full' },
      // IMPORTANT: 'new' must come before ':id/edit' so Angular doesn't treat 'new' as an id
      { path: 'products/new',
        loadComponent: () => import('./admin components/product-form/product-form.component').then(m => m.ProductFormComponent) },
      { path: 'products/:id/edit',
        loadComponent: () => import('./admin components/product-form/product-form.component').then(m => m.ProductFormComponent) },
      { path: 'products',
        loadComponent: () => import('./admin components/product-mngmt/product-mngmt.component').then(m => m.ProductMngmtComponent) },
      { path: 'customers',
        loadComponent: () => import('./admin components/customer-mngmt/customer-mngmt.component').then(m => m.CustomerMngmtComponent) },
      { path: 'orders',
        loadComponent: () => import('./admin components/order-mngmt/order-mngmt.component').then(m => m.OrderMngmtComponent) },
    ]
  },

  { path: '**', redirectTo: 'home' }
];