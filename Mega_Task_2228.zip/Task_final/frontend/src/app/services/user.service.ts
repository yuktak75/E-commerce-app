import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class UserService {
  private base = 'http://localhost:3000/api';

  constructor(private http: HttpClient) {}

  getProfile(): Observable<any> {
    return this.http.get(`${this.base}/user/profile`, { withCredentials: true });
  }

  updateProfile(data: { name?: string; email?: string }): Observable<any> {
    return this.http.put(`${this.base}/user/profile`, data, { withCredentials: true });
  }

  getMyOrders(): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/orders/my-orders`, { withCredentials: true });
  }

  getOrderDetails(id: number): Observable<any> {
    return this.http.get(`${this.base}/orders/my-orders/${id}`, { withCredentials: true });
  }

  checkout(paymentMethod: string): Observable<any> {
    return this.http.post(`${this.base}/orders/checkout`, { paymentMethod }, { withCredentials: true });
  }
}