import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AdminService {
  private base = 'http://localhost:3000/api';

  constructor(private http: HttpClient) {}

  // Products
  getProducts(filters: any = {}): Observable<any> {
    const params: any = {};
    Object.keys(filters).forEach(k => { if (filters[k] !== null && filters[k] !== '') params[k] = filters[k]; });
    return this.http.get(`${this.base}/products`, { params, withCredentials: true });
  }

  getProductById(id: number): Observable<any> {
    return this.http.get(`${this.base}/products/${id}`, { withCredentials: true });
  }

  addProduct(formData: FormData): Observable<any> {
    return this.http.post(`${this.base}/products`, formData, { withCredentials: true });
  }

  updateProduct(id: number, formData: FormData): Observable<any> {
    return this.http.put(`${this.base}/products/${id}`, formData, { withCredentials: true });
  }

  deleteProduct(id: number): Observable<any> {
    return this.http.delete(`${this.base}/products/${id}`, { withCredentials: true });
  }

  getTaxonomy(): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/products/taxonomy`, { withCredentials: true });
  }

  // Customers
  getAllCustomers(): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/user`, { withCredentials: true });
  }

  toggleLock(userId: number): Observable<any> {
    return this.http.patch(`${this.base}/user/${userId}/toggle-lock`, {}, { withCredentials: true });
  }

  // Orders
  getAllOrders(): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/orders/admin/all`, { withCredentials: true });
  }

  getOrderDetails(id: number): Observable<any> {
    return this.http.get(`${this.base}/orders/admin/${id}`, { withCredentials: true });
  }
}