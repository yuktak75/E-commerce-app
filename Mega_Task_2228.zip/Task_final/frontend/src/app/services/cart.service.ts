import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, tap } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class CartService {
  private apiUrl = 'http://localhost:3000/api/cart';
  private cartItemsSubject = new BehaviorSubject<any[]>([]);
  public cartItems$ = this.cartItemsSubject.asObservable();

  constructor(private http: HttpClient) {}

  loadCart() {
    this.http.get<any[]>(this.apiUrl, { withCredentials: true })
      .subscribe({
        next: items => this.cartItemsSubject.next(items),
        error: () => this.cartItemsSubject.next([])
      });
  }

  addToCart(productId: number, quantity: number): Observable<any> {
    return this.http.post(this.apiUrl, { productId, quantity }, { withCredentials: true })
      .pipe(tap(() => this.loadCart()));
  }

  updateQuantity(itemId: number, quantity: number): Observable<any> {
    return this.http.put(`${this.apiUrl}/${itemId}`, { quantity }, { withCredentials: true })
      .pipe(tap(() => this.loadCart()));
  }

  removeFromCart(itemId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${itemId}`, { withCredentials: true })
      .pipe(tap(() => this.loadCart()));
  }

  clearLocalCart() {
    this.cartItemsSubject.next([]);
  }
}