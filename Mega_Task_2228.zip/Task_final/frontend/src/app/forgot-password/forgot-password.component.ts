import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-forgot-password',
  imports: [FormsModule, CommonModule],
  templateUrl: './forgot-password.component.html',
  styleUrl: './forgot-password.component.css'
})
export class ForgotPasswordComponent {
  step: 1 | 2 | 3 = 1;
  email = '';
  code = '';
  generatedCode = '';
  newPassword = '';
  confirmPassword = '';
  error = '';
  success = '';
  loading = false;
 
  constructor(private authService: AuthService) {}
 
  requestCode() {
    if (!this.email) { this.error = 'Please enter your email.'; return; }
    this.loading = true; this.error = '';
    this.authService.forgotPassword(this.email).subscribe({
      next: (res: any) => {
        this.loading = false;
        this.generatedCode = res.code; // Mock: displayed on screen
        this.step = 2;
      },
      error: (err) => { this.loading = false; this.error = err.message || 'Email not found.'; }
    });
  }
 
  verifyCode() {
    if (!this.code) { this.error = 'Please enter the code.'; return; }
    if (this.code !== this.generatedCode) { this.error = 'Incorrect code.'; return; }
    this.error = '';
    this.step = 3;
  }
 
  resetPassword() {
    if (!this.newPassword || !this.confirmPassword) { this.error = 'Please fill in all fields.'; return; }
    if (this.newPassword.length < 6) { this.error = 'Password must be at least 6 characters.'; return; }
    if (this.newPassword !== this.confirmPassword) { this.error = 'Passwords do not match.'; return; }
    this.loading = true; this.error = '';
    this.authService.resetPassword(this.email, this.code, this.newPassword).subscribe({
      next: () => {
        this.loading = false;
        this.success = 'Password reset successfully! You can now log in.';
        this.step = 1;
      },
      error: (err) => { this.loading = false; this.error = err.message || 'Reset failed.'; }
    });
  }
}
