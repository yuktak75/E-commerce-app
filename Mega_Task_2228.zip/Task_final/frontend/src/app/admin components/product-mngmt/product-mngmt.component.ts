import { Component } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-product-mngmt',
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './product-mngmt.component.html',
  styleUrl: './product-mngmt.component.css'
})
export class ProductMngmtComponent {
  products: any[] = [];
  loading = true;
  deletingId: number | null = null;
  message = '';
  error = '';
 
  constructor(private adminService: AdminService) {}
 
  ngOnInit() { this.loadProducts(); }
 
  loadProducts() {
    this.loading = true;
    this.adminService.getProducts({ limit: 100 }).subscribe({
      next: (res: any) => { this.products = res.products || res; this.loading = false; },
      error: () => this.loading = false
    });
  }
 
  getImageUrl(imagePath: string) {
    if (!imagePath) return 'backend/ProductImages/placeholder.jpg';
    return `http://localhost:3000/${imagePath}`;
  }
 
  deleteProduct(id: number, name: string) {
    if (!confirm(`Delete "${name}"? This cannot be undone.`)) return;
    this.deletingId = id;
    this.adminService.deleteProduct(id).subscribe({
      next: () => {
        this.deletingId = null;
        this.message = `"${name}" deleted.`;
        this.products = this.products.filter(p => p.id !== id);
        setTimeout(() => this.message = '', 3000);
      },
      error: (err) => { this.deletingId = null; this.error = err.message; setTimeout(() => this.error = '', 3000); }
    });
  }
}
