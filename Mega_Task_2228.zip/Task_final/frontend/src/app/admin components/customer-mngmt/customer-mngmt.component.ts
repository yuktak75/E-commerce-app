import { Component } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-customer-mngmt',
  imports: [CommonModule],
  templateUrl: './customer-mngmt.component.html',
  styleUrl: './customer-mngmt.component.css'
})
export class CustomerMngmtComponent {
  customers: any[] = [];
  loading = true;
  togglingId: number | null = null;
  message = '';
 
  constructor(private adminService: AdminService) {}
 
  ngOnInit() {
    this.adminService.getAllCustomers().subscribe({
      next: (customers) => { this.customers = customers; this.loading = false; },
      error: () => this.loading = false
    });
  }
 
  toggleLock(customer: any) {
    const action = customer.isLocked ? 'unlock' : 'lock';
    if (!confirm(`Are you sure you want to ${action} ${customer.name}'s account?`)) return;
    this.togglingId = customer.id;
    this.adminService.toggleLock(customer.id).subscribe({
      next: (res: any) => {
        customer.isLocked = res.isLocked;
        this.togglingId = null;
        this.message = `${customer.name} has been ${res.isLocked ? 'locked' : 'unlocked'}.`;
        setTimeout(() => this.message = '', 3000);
      },
      error: () => this.togglingId = null
    });
  }
}
