import { Component } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AdminService } from '../../services/admin.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product-form',
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './product-form.component.html',
  styleUrl: './product-form.component.css'
})
export class ProductFormComponent {
  isEdit = false;
  productId: number | null = null;
  loading = false;
  pageLoading = true;
  error = '';
  success = '';
 
  // Form fields
  name = '';
  description = '';
  price: number | null = null;
  stockQuantity: number | null = null;
  selectedTypeId: number | null = null;
  selectedCategoryId: number | null = null;
  selectedSubCategoryId: number | null = null;
  imageFile: File | null = null;
  existingImage = '';
 
  taxonomy: any[] = [];
 
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private adminService: AdminService
  ) {}
 
  ngOnInit() {
    this.adminService.getTaxonomy().subscribe({ next: (t) => this.taxonomy = t });
 
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.isEdit = true;
      this.productId = +id;
      this.adminService.getProductById(+id).subscribe({
        next: (p) => {
          this.name = p.name;
          this.description = p.description;
          this.price = p.price;
          this.stockQuantity = p.stockQuantity;
          this.existingImage = p.imagePath;
          // Pre-select taxonomy
          this.selectedSubCategoryId = p.subCategory?.id;
          this.selectedCategoryId = p.subCategory?.category?.id;
          this.selectedTypeId = p.subCategory?.category?.type?.id;
          this.pageLoading = false;
        },
        error: () => { this.error = 'Product not found.'; this.pageLoading = false; }
      });
    } else {
      this.pageLoading = false;
    }
  }
 
  get categories() {
    const type = this.taxonomy.find(t => t.id == this.selectedTypeId);
    return type ? type.categories : [];
  }
 
  get subCategories() {
    const type = this.taxonomy.find(t => t.id == this.selectedTypeId);
    if (!type) return [];
    const cat = type.categories.find((c: any) => c.id == this.selectedCategoryId);
    return cat ? cat.subCategories : [];
  }
 
  onTypeChange() { this.selectedCategoryId = null; this.selectedSubCategoryId = null; }
  onCategoryChange() { this.selectedSubCategoryId = null; }
 
  onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.imageFile = input.files[0];
    }
  }
 
  getImageUrl(imagePath: string) {
    if (!imagePath) return 'assets/placeholder.png';
    return `http://localhost:3000/${imagePath}`;
  }
 
  submit() {
    this.error = '';
    if (!this.name || !this.description || this.price === null || this.stockQuantity === null || !this.selectedSubCategoryId) {
      this.error = 'All fields including sub-category are required.'; return;
    }
    if (this.price <= 0) { this.error = 'Price must be greater than 0.'; return; }
    if (this.stockQuantity < 0) { this.error = 'Stock cannot be negative.'; return; }
 
    const formData = new FormData();
    formData.append('name', this.name);
    formData.append('description', this.description);
    formData.append('price', String(this.price));
    formData.append('stockQuantity', String(this.stockQuantity));
    formData.append('subCategoryId', String(this.selectedSubCategoryId));
    if (this.imageFile) formData.append('image', this.imageFile);
 
    this.loading = true;
    const req = this.isEdit
      ? this.adminService.updateProduct(this.productId!, formData)
      : this.adminService.addProduct(formData);
 
    req.subscribe({
      next: () => {
        this.loading = false;
        this.success = this.isEdit ? 'Product updated!' : 'Product added!';
        setTimeout(() => this.router.navigate(['/admin/products']), 1200);
      },
      error: (err) => { this.loading = false; this.error = err.message || 'Save failed.'; }
    });
  }
}
