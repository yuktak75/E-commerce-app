import { Component } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-order-mngmt',
  imports: [CommonModule],
  templateUrl: './order-mngmt.component.html',
  styleUrl: './order-mngmt.component.css'
})
export class OrderMngmtComponent {
  orders: any[] = [];
  loading = true;
  selectedOrder: any = null;
  detailLoading = false;
 
  constructor(private adminService: AdminService) {}
 
  ngOnInit() {
    this.adminService.getAllOrders().subscribe({
      next: (orders) => { this.orders = orders; this.loading = false; },
      error: () => this.loading = false
    });
  }
 
  viewDetails(order: any) {
    if (this.selectedOrder?.id === order.id) { this.selectedOrder = null; return; }
    this.detailLoading = true;
    this.adminService.getOrderDetails(order.id).subscribe({
      next: (o) => { this.selectedOrder = o; this.detailLoading = false; },
      error: () => this.detailLoading = false
    });
  }
 
  closeDetail() { this.selectedOrder = null; }
}
