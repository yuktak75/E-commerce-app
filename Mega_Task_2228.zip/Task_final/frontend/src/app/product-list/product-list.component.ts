import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ProductService } from '../services/product.service';
import { CartService } from '../services/cart.service';
import { AuthService } from '../services/auth.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product-list',
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent implements OnInit{
  products: any[] = [];
  taxonomy: any[] = [];
  loading = false;
  total = 0;
  pages = 1;
  cartMessage = '';
  addingId: number | null = null;
 
  filters = {
    search: '',
    typeId: '',
    categoryId: '',
    subCategoryId: '',
    minPrice: '',
    maxPrice: '',
    sortBy: '',
    page: 1,
    limit: 12
  };
 
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productService: ProductService,
    private cartService: CartService,
    public authService: AuthService
  ) {}
 
  ngOnInit() {
    this.productService.getTaxonomy().subscribe({ next: (d: any[]) => this.taxonomy = d });
    this.route.queryParams.subscribe(params => {
      this.filters.search = params['search'] || '';
      this.filters.typeId = params['typeId'] || '';
      this.filters.categoryId = params['categoryId'] || '';
      this.filters.subCategoryId = params['subCategoryId'] || '';
      this.filters.minPrice = params['minPrice'] || '';
      this.filters.maxPrice = params['maxPrice'] || '';
      this.filters.sortBy = params['sortBy'] || '';
      this.filters.page = params['page'] ? +params['page'] : 1;
      this.fetchProducts();
    });
  }
 
  fetchProducts() {
    this.loading = true;
    const f: any = { ...this.filters };
    Object.keys(f).forEach(k => { if (!f[k] && f[k] !== 0) delete f[k]; });
    this.productService.getProducts(f).subscribe({
      next: (res: any) => {
        this.products = res.products || res;
        this.total = res.total || this.products.length;
        this.pages = res.pages || 1;
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }
 
  applyFilters() {
    this.filters.page = 1;
    const q: any = {};
    if (this.filters.search) q['search'] = this.filters.search;
    if (this.filters.typeId) q['typeId'] = this.filters.typeId;
    if (this.filters.categoryId) q['categoryId'] = this.filters.categoryId;
    if (this.filters.subCategoryId) q['subCategoryId'] = this.filters.subCategoryId;
    if (this.filters.minPrice) q['minPrice'] = this.filters.minPrice;
    if (this.filters.maxPrice) q['maxPrice'] = this.filters.maxPrice;
    if (this.filters.sortBy) q['sortBy'] = this.filters.sortBy;
    this.router.navigate(['/products'], { queryParams: q });
  }
 
  clearFilters() {
    this.router.navigate(['/products']);
  }
 
  setPage(p: number) {
    if (p < 1 || p > this.pages) return;
    this.filters.page = p;
    this.fetchProducts();
    window.scrollTo(0, 0);
  }
 
  getCategories() {
    const type = this.taxonomy.find(t => t.id == this.filters.typeId);
    return type ? type.categories : [];
  }
 
  getSubCategories() {
    const type = this.taxonomy.find(t => t.id == this.filters.typeId);
    if (!type) return [];
    const cat = type.categories.find((c: any) => c.id == this.filters.categoryId);
    return cat ? cat.subCategories : [];
  }
 
  getImageUrl(imagePath: string) {
    if (!imagePath) return 'backend/ProductImages/placeholder.jpg';
    return `http://localhost:3000/${imagePath}`;
  }
 
  addToCart(product: any) {
    this.addingId = product.id;
    this.cartService.addToCart(product.id, 1).subscribe({
      next: () => {
        this.addingId = null;
        this.cartMessage = `${product.name} added!`;
        setTimeout(() => this.cartMessage = '', 2000);
      },
      error: (err) => { this.addingId = null; this.cartMessage = err.message; setTimeout(() => this.cartMessage = '', 2500); }
    });
  }
 
  pageRange() {
    return Array.from({ length: this.pages }, (_, i) => i + 1);
  }
}
