import { Component, OnInit } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { AuthService } from './services/auth.service';
import { CartService } from './services/cart.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, FormsModule, CommonModule, RouterLink],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  currentUser: any = null;
  cartCount = 0;
  searchQuery = '';
  sessionChecked = false;
 
  constructor(
    public authService: AuthService,
    private cartService: CartService,
    private router: Router
  ) {}
 
  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      this.sessionChecked = true;
      if (user && user.role === 'Customer') this.cartService.loadCart();
      else this.cartService.clearLocalCart();
    });
    this.cartService.cartItems$.subscribe(items => {
      this.cartCount = items.reduce((sum, i) => sum + i.quantity, 0);
    });
  }
 
  search() {
    if (this.searchQuery.trim()) {
      this.router.navigate(['/products'], { queryParams: { search: this.searchQuery.trim() } });
      this.searchQuery = '';
    }
  }
 
  logout() {
    this.authService.logout().subscribe(() => this.router.navigate(['/home']));
  }
}
