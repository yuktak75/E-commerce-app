import { Component } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ProductService } from '../services/product.service';
import { CartService } from '../services/cart.service';
import { AuthService } from '../services/auth.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product-detail',
  imports: [FormsModule, CommonModule, RouterLink],
  templateUrl: './product-detail.component.html',
  styleUrl: './product-detail.component.css'
})

export class ProductDetailComponent {
  // product-detail.component.ts
product: any = null;
  loading = true;
  quantity = 1;
  cartMessage = '';
  addingToCart = false;
  shareCopied = false;
 
  constructor(
    private route: ActivatedRoute,
    private productService: ProductService,
    private cartService: CartService,
    public authService: AuthService
  ) {}
 
  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id')!;
    this.productService.getProductById(id).subscribe({
      next: (p) => { this.product = p; this.loading = false; },
      error: () => this.loading = false
    });
  }
 
  getImageUrl(imagePath: string) {
    if (!imagePath) return 'backend/ProductImages/placeholder.jpg';
    return `http://localhost:3000/${imagePath}`;
  }
 
  addToCart() {
    if (!this.product || this.quantity < 1) return;
    this.addingToCart = true;
    this.cartService.addToCart(this.product.id, this.quantity).subscribe({
      next: () => {
        this.addingToCart = false;
        this.cartMessage = 'Added to cart successfully!';
        setTimeout(() => this.cartMessage = '', 2500);
      },
      error: (err) => {
        this.addingToCart = false;
        this.cartMessage = err.message || 'Failed to add to cart.';
        setTimeout(() => this.cartMessage = '', 2500);
      }
    });
  }
 
  shareProduct() {
    if (navigator.share) {
      navigator.share({ title: this.product.name, url: window.location.href }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href).then(() => {
        this.shareCopied = true;
        setTimeout(() => this.shareCopied = false, 2000);
      });
    }
  }
}
