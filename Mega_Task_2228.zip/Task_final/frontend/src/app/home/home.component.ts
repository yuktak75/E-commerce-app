import { Component } from '@angular/core';
import { ProductService } from '../services/product.service';
import { CartService } from '../services/cart.service';
import { AuthService } from '../services/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  featuredProducts: any[] = [];
  taxonomy: any[] = [];
  loading = true;
  addingId: number | null = null;
  cartMessage = '';
 
  constructor(
    private productService: ProductService,
    private cartService: CartService,
    public authService: AuthService
  ) {}
 
  ngOnInit() {
    this.productService.getProducts({ limit: 8 }).subscribe({
      next: (res: any) => { this.featuredProducts = res.products || res; this.loading = false; },
      error: () => { this.loading = false; }
    });
    this.productService.getTaxonomy().subscribe({
      next: (data: any[]) => this.taxonomy = data,
      error: () => {}
    });
  }
 
  getImageUrl(imagePath: string): string {
    if (!imagePath) return 'backend/ProductImages/placeholder.jpg';
    return `http://localhost:3000/${imagePath}`;
  }
 
  addToCart(product: any) {
    if (!this.authService.isLoggedIn()) return;
    this.addingId = product.id;
    this.cartService.addToCart(product.id, 1).subscribe({
      next: () => {
        this.addingId = null;
        this.cartMessage = `${product.name} added to cart!`;
        setTimeout(() => this.cartMessage = '', 2500);
      },
      error: (err) => { this.addingId = null; this.cartMessage = err.message; setTimeout(() => this.cartMessage = '', 2500); }
    });
  }
}
