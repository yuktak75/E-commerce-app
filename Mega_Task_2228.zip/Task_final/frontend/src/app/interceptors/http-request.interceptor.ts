import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

export const httpRequestInterceptor: HttpInterceptorFn = (req, next) => {
  // const authService = inject(AuthService);
  // const router = inject(Router);

  // return next(req).pipe(catchError((error:HttpErrorResponse) => {
  //   if (error.status === 401){
  //     authService.logout().subscribe();
  //     router.navigate(['/login'], {queryParams: {error: 'Session expired or account locked'}});
  //   }
  //   const errorMessage = error.error?.message || 'A server error occured';

  //   return throwError(() => new Error(errorMessage));
  // })
  // );
  const router = inject(Router);  // ← only inject Router, not AuthService

  return next(req).pipe(
    catchError((error: HttpErrorResponse) => {
      if (error.status === 401) {
        router.navigate(['/login'], { queryParams: { error: 'Session expired or account locked' } });
      }
      const errorMessage = error.error?.message || 'A server error occurred';
      return throwError(() => new Error(errorMessage));
    })
  );
  
};
