import type { Request, Response } from "express";
import { AppDataSource } from "../../data-source.js";
import { User } from "../entities/user.js";
import bcrypt from 'bcrypt';
import {v4 as uuidv4} from 'uuid';
import { sessionStore } from "../middleware/auth.middleware.js";

const userRepo = AppDataSource.getRepository(User);
const resetCodes = new Map<string, {code:string; expires: number}>();

export class AuthController{
    // Register new user
    static register = async (req:Request, res:Response) => {
        try{
            // Request name, email, password from user
            const {name, email, password} = req.body;
            const existingUser = await userRepo.findOneBy({email});

            // If user already exists
            if (existingUser){
                return res.status(400).json({message: "User already registered"});
            }

            // Encrypt password using bcrypt
            const hashedPassword = await bcrypt.hash(password, 10);

            // Save new user
            const newUser = userRepo.create({name, email, password:hashedPassword});
            await userRepo.save(newUser);
            return res.status(201).json({message:"User registered successfully!"});
        }
        catch(err){
            return res.status(500).json({message: "Error while registering user: ", err});
        }
    }

    // Login user
    static login = async (req:Request, res:Response) => {
        try{
            // Request credentials from user
            const {email, password} = req.body;

            // Find user
            const user = await userRepo.findOne({
                where: {email},
                select: ['id', 'password', 'role','isLocked','name']
            });

            // Check if user exists and if password matches or not
            if(!user || !(await bcrypt.compare(password, user.password!))){
                return res.status(401).json({message:"Invalid credentials"});
            }

            // Check if user's account is locked or not
            if(user.isLocked){
                return res.status(403).json({message:"Account is locked by admin! Kindly contact admin."});
            }

            // Session and cookie security
            const sessionId = uuidv4();
            sessionStore.set(sessionId, {userId: user.id!, role: user.role as any});

            res.cookie('session_id', sessionId, {
                httpOnly:true,
                secure:false, // set true if using https
                sameSite:'strict',
                maxAge: 3600000 // 1hr
            });

            res.json({
                message: "Login successful",
                // token: sessionId, 
                name:user.name, 
                role: user.role
            });
        }
        catch(err){
            return res.status(500).json({message:"Error occured while logging in: ", err});
        }
    }

    // Logout => clears both client and server side
    static logout = async (req:Request, res:Response) => {
        try{
            // Finds sessionId from headers and deletes the session
            // const authHeader = req.headers['authorization'];
            // const sessionId = authHeader && authHeader.split(' ')[1];
            const sessionId = req.cookies.session_id;

            if (sessionId) sessionStore.delete(sessionId);

            res.clearCookie('session_id', {
                httpOnly: true,
                secure: process.env.NODE_ENV === 'production',
                sameSite: 'strict'
            });
            res.json({message:"Logged out successfully"});
        }
        catch(err){
            return res.status(500).json({message:"Error occured while logging out: ", err});
        }
    }

    // Forgot Password => Reset password
    static requestReset = async (req:Request, res:Response) => {
        try{
            // Request email from user
            const {email} = req.body;

            const user = await userRepo.findOneBy({email});
            if (!user){
                return res.status(404).json({message:"User not found"});
            }

            // Generate a random 6 digit code
            const code = Math.floor(100000 + Math.random() * 900000).toString();
            resetCodes.set(email, {code, expires: Date.now() + 600000});

            res.json({message: "Reset code generated: ", code});
        }
        catch(err){
            return res.status(500).json({message:"Error occured while requesting reset password: ", err});
        }
    }

    static resetPassword = async (req:Request, res:Response) => {
        try{
            const {email, code, newPassword} = req.body;

            // Record is an object here that contains email, code and expires
            const record = resetCodes.get(email);

            // Check if record exists or the code hasn't expired yet or if the code matches
            if (!record || record.code !== code || record.expires < Date.now()){
                return res.status(400).json({message:"Invalid or expired code"});
            }

            // Finds user and reset the password to new one 
            // Encrypt the new password first and then save
            const user = await userRepo.findOneBy({email});
            if (user){
                user.password = await bcrypt.hash(newPassword, 10);
                await userRepo.save(user);
                resetCodes.delete(email);
                return res.json({message: "Password updated successfully"});
            }
            return res.status(404).json({message:"User not found!"});
        }
        catch(err){
            return res.status(500).json({message:"Error occured while resetting password: ", err});
        }
    }

    // Change password
    static changePassword = async (req:Request, res:Response) => {
        try{
            // Request current and new password from user
            const {currentPassword, newPassword} = req.body;

            // Finds user using userId -> refer to auth.middleware.ts
            const sessionUser = (req as any).user;
            const user = await userRepo.findOne({
                where: {id:sessionUser.userId},
                select: ['id', 'password']
            });

            // Checks if user exists or currently typed password matches to the original one 
            if (!user || !(await bcrypt.compare(currentPassword, user.password!))){
                return res.status(400).json({message:"Passwords don't match"});
            }

            // Encrypt the new password and save 
            user.password = await bcrypt.hash(newPassword, 10);
            await userRepo.save(user);
            return res.json({message:"Password changed successfully"});
        }
        catch(err){
            return res.status(500).json({message:"Error occured while changing password: ", err});
        }
    }
}