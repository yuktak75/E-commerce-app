import type { Request, Response } from "express";
import { AppDataSource } from "../../data-source.js";
import { Product } from "../entities/product.js";
import { Between, LessThanOrEqual, Like, MoreThanOrEqual, type FindOptionsOrder } from "typeorm";

const productRepo = AppDataSource.getRepository(Product);

// getProducts, getProductById, addProduct, deleteProduct
export class ProductController{
    static getProducts = async (req:Request, res:Response) => {
        try{
            const {search, subCategoryId, categoryId, typeId, minPrice, maxPrice, sortBy, page = "1", limit = "10"} = req.query;

            // let queryOptions: any = {
            //     relations: ['subCategory', 'subCategory.category', 'subCategory.category.type']
            // }

            const pageNum = Math.max(1, parseInt(page as string));
            const limitNum = Math.min(50, Math.max(1, parseInt(limit as string)));
            const skip = (pageNum - 1) * limitNum;

            const where:any = {};
            // Text search
            if (search){
                where.name = Like(`%${search}%`);
            }

            // Category filter
            if (subCategoryId){
                where.subCategory = {id:Number(subCategoryId)};
            }

            // Price range filter
            if (minPrice && maxPrice){
                where.price = Between(Number(minPrice), Number(maxPrice));
            }
            else if (minPrice){
                where.price = MoreThanOrEqual(Number(minPrice));
            }
            else if (maxPrice){
                where.price = LessThanOrEqual(Number(maxPrice));
            }

            // queryOptions.where = where;
            // const products = await productRepo.find(queryOptions);

            const orderOptions: FindOptionsOrder<Product> = {id: 'DESC'};
            if (sortBy === 'price') {
                orderOptions.price = 'ASC';
            }
            const products = await productRepo.find({
                where: where,
                relations: ['subCategory', 'subCategory.category'],
                order: orderOptions
            })
            return res.json(products);
        }
        catch(err){
            return res.status(500).json({message: "Error occured while getting products: ", err});
        }
    }

    static getProductById = async (req:Request, res:Response) => {
        try{
            const {id} = req.params;
            const product = await productRepo.findOne({
                where: {id:Number(id)},
                relations:['subCategory']
            });

            if (!product){
                return res.status(404).json({message:"Product not found"});
            }
            return res.json(product);
        }
        catch(err){
            return res.status(500).json({message:"Error occured while getting product by id: ", err});
        }
    }

    static addProduct = async (req:Request, res:Response) => {
        try{
            const {name, description, price, stockQuantity, subCategoryId} = req.body;

            if(!name || !description || !price || !stockQuantity || !subCategoryId){
                return res.status(400).json({message: "All fields are required"});
            }
            if (Number(price) <= 0){
                return res.status(400).json({message: "Price must be greater than 0"});
            }
            if (Number(stockQuantity) < 0){
                return res.status(400).json({message: "Stock quantity cannot be negative"});
            }
            const newProduct = productRepo.create({
                name, description,
                price: Number(price),
                stockQuantity: Number(stockQuantity),
                subCategory: {id:Number(subCategoryId)} as any,
            });
            await productRepo.save(newProduct);
            return res.status(201).json({message: "Product added: ", product:newProduct});
        }
        catch(err){
            return res.status(400).json({message:"Failed to add product due to: ", err});
        }
    }

    static deleteProduct = async (req:Request, res:Response) => {
        try{
            const {id} = req.params;
            await productRepo.delete(Number(id));
            return res.json({message:"Product deleted successfully"});
        }
        catch(err){
            return res.status(500).json({message:"Error deleting product"});
        }
    }
}