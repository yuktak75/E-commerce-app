import { AppDataSource } from "../../data-source.js";
import { CartItem } from "../entities/cartItem.js";
import { Order} from "../entities/order.js";
import { OrderItem } from "../entities/orderItem.js";
import { Product } from "../entities/product.js";
import type { Request, Response } from "express";

const orderRepo = AppDataSource.getRepository(Order);
const cartRepo = AppDataSource.getRepository(CartItem);
const productRepo = AppDataSource.getRepository(Product);

// checkout, getMyOrders, getOrderDetails, getAllOrders
export class OrderController{

    // Checkout the orders
    static checkout = async(req:Request, res:Response) => {
        // QueryRunner is used because if the server crashes at any point, the transaction "rolls back" => as if order never happened
        const queryRunner = AppDataSource.createQueryRunner();

        // Host, port, username, password
        // Links node.js server and database
        await queryRunner.connect();

        // Without transaction => user might accidentally buy same items twice or sell a product not available in warehouse 
        await queryRunner.startTransaction();

        try{
            // Retrieve user's information
            const userId = (req as any).user.userId;
            const {paymentMethod} = req.body;

            // Find cartItems of that person
            const cartItems = await cartRepo.find({
                where: {user: {id:userId}},
                relations:['product']
            });

            // Check if cart is empty
            if (cartItems.length === 0){
                return res.status(400).json({message:"Your cart is empty!"});
            }

            // Calculate the total amount of items present in cart
            let totalAmt = 0;
            for (const item of cartItems){
                if (!item.product){
                    throw new Error("The product no longer exists in your cart");
                }
                if (item.product.stockQuantity! < item.quantity){
                    throw new Error (`Product ${item.product.name} is out of stock!`);
                }
                totalAmt += Number(item.product.price) * item.quantity;
            }

            // Record the order
            const newOrder = orderRepo.create({
                user: {id:userId} as any,
                paymentMethod: paymentMethod,
                totalAmount: totalAmt
            });
            const savedOrder = await queryRunner.manager.save(newOrder);

            for (const item of cartItems){
                const orderItem = queryRunner.manager.create(OrderItem, {
                    productName: item.product.name!,
                    priceAtPurchase: item.product.price!,
                    quantity: item.quantity,
                    order:savedOrder
                });
                await queryRunner.manager.save(orderItem);


                await queryRunner.manager.decrement(
                    require('../entities/product.js').Product,
                    {id: item.product.id},
                    'stockQuantity',item.quantity
                );
                // const product = item.product;
                // product.stockQuantity! -= item.quantity;
                // await queryRunner.manager.save(product);
            }

            // Clear cart after order is completed
            await queryRunner.manager.delete(CartItem, {user: {id:userId}});

            // Save changes
            await queryRunner.commitTransaction();

            return res.status(201).json({
                message:"Order placed successfully", 
                orderId: savedOrder.id, 
                totalAmount: totalAmt, 
                paymentMethod: savedOrder.paymentMethod
            });

        }
        catch(err:any){
            // If any error occurs roll back the transaction
            await queryRunner.rollbackTransaction();
            return res.status(400).json({message:err.message || "Transaction failed"});
        }
        finally{
            // Never omit it while using queryRunner
            // Runs even if checkout fails
            await queryRunner.release();
        }
    }

    static getMyOrders = async(req:Request, res:Response) => {
        try{
            const userId = (req as any).user.userId;

            const order = await orderRepo.find({
                where: {user: {id:userId}},
                relations:['items'],
                order: {orderDate: "DESC"}
            });
            return res.json(order);
        }
        catch(err){
            return res.status(500).json({message:"Error while getting user's orders: ", err});
        }
    }

    static getAllOrders = async (req:Request, res:Response) => {
        try{
            const orders = await orderRepo.find({
                relations: ["items", "user"],
                order: {orderDate: "DESC"}
            });
            return res.json(orders);
        }
        catch(err){
            return res.status(500).json({message:"Error while getting all orders: ", err});
        }
    }

    static getOrderDetails = async(req:Request, res:Response) => {
        try{
            const {id} = req.params;
            const userId = (req as any).user.userId;
            const userRole = (req as any).user.role;

            const order = await orderRepo.findOne({
                where: {id:Number(id)},
                relations: ['items', 'user']
            });

            if (!order){
                return res.status(404).json({message:"Order not found"});
            }

            if (order.user?.id !== userId && userRole !== 'Admin'){
                return res.status(403).json({message:"Access denied to this order"});
            }
            return res.json(order);
        }
        catch(err){
            return res.status(500).json({message:"Error while fetching order details: ", err});
        }
    }
}