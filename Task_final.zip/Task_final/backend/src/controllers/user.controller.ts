import type { Request, Response } from "express";
import { AppDataSource } from "../../data-source.js";
import { User } from "../entities/user.js";

const userRepo = AppDataSource.getRepository(User);

export class UserController{
    // Get all customers
    static getAllCustomers = async(req:Request, res:Response) => {
        try{
            // Fetch all customers from repository
            const customers = await userRepo.find({
                where:{role:'Customer'},
                select: ['id', 'name', 'email', 'isLocked', 'role']
            });
            return res.json(customers);
        }
        catch(err){
            return res.status(500).json({message:"Error while getting all customers: ", err});
        }
    }

    // Toggle Lock
    static toggleLock = async(req:Request, res:Response) => {
        try{
            // Get user by id to lock/unlock
            const {id} = req.params;
            const user = await userRepo.findOneBy({id:Number(id)});

            // Checks if user exists
            if (!user){
                return res.status(404).json({message:"User not found"});
            }

            // Toggles lock and saves
            user.isLocked = !user.isLocked;
            await userRepo.save(user);

            return res.json({
                message:`User ${user.isLocked ? 'locked' : 'unlocked'} successful`,
                isLocked: user.isLocked
            });
        }
        catch(err){
            return res.status(500).json({message:"Error while toggling lock: ", err});
        }
    }

    static updateProfile = async(req:Request, res:Response) => {
        try{
            // Request credentials from user and find that user
            const {name, email} = req.body;
            // Refer to auth.middleware.ts
            const sessionUser = (req as any).user;
            const user = await userRepo.findOneBy({id:sessionUser.userId});

            // Checks if user exists
            if(!user){
                return res.status(404).json({message:"User not found"});
            }

            // Check if email is already in use and update email accordingly
            if (email && email !== user.email){
                const emailExists = await userRepo.findOneBy({email});
                if (emailExists){
                    return res.status(400).json({message:"Email already in use"});
                }
                user.email = email;
            }
            // If name is given -> update name
            if (name) user.name = name;

            // Save user
            await userRepo.save(user);
            return res.json({message:"Profile updated successfully", name: user.name, email: user.email});
        }
        catch(err){
            return res.status(500).json({message:"Error while updating profile: ", err});
        }
    }
}