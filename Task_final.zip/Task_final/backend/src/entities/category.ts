import { Column, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { Type } from "./type.js";
import { SubCategory } from "./subcat.js";

@Entity()
export class Category{
    @PrimaryGeneratedColumn()
    id!:number;

    @Column({type:'varchar', length:150})
    name!:string;

    // Many categories have one type
    @ManyToOne("Type", (type:any) => type.categories)
    type!:any;

    // 1 category can have many subcategories
    @OneToMany("SubCategory", (sub:any) => sub.category)
    subCategories!:any[];
}