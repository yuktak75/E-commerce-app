import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { Order } from "./order.js";

@Entity('users')
export class User{
    @PrimaryGeneratedColumn()
    id!:number;

    @Column({type:'varchar', length: 150})
    name!:string;

    @Column({type:"varchar", unique:true})
    email!:string;

    @Column({type:"varchar",select:false})
    password!:string;

    @Column({type: 'varchar', default: 'Customer'})
    role!:'Customer' | 'Admin';

    @Column({type:"boolean", default:false})
    isLocked!:boolean;

    // 1 User can have many orders
    @OneToMany("Order", (order:any) => order.user)
    orders!:any[];
}

