import { Column, CreateDateColumn, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { User } from "./user.js";
import type { OrderItem } from "./orderItem.js";

@Entity()
export class Order{
    @PrimaryGeneratedColumn()
    id!:number;

    @CreateDateColumn()
    orderDate!:Date;

    @Column({ type:"varchar", default: "Cash"})
    paymentMethod!:"Cash" | "Debit Card" | "Credit Card";

    @Column({type: 'decimal', precision: 10, scale:2})
    totalAmount!:number;

    // Many users can have 1 order
    @ManyToOne("User", (user:any) => user.orders)
    user!:any;

    // 1 Order can have many items
    @OneToMany("OrderItem", (orderitem:any) => orderitem.order, {cascade:true})
    items!:any[];
}

