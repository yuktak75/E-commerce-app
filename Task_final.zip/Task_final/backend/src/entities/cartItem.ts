import { Entity, Column, PrimaryGeneratedColumn, ManyToOne } from "typeorm";
import { User } from "./user.js";
import { Product } from "./product.js";

@Entity()
export class CartItem{
    @PrimaryGeneratedColumn()
    id!:number;

    @Column('int')
    quantity!:number;

    @ManyToOne(() => User)
    user!:User;

    @ManyToOne(() => Product)
    product!:Product;
}