import { AppDataSource } from "../../data-source.js";
import { Category } from "../entities/category.js";
import { Product } from "../entities/product.js";
import { SubCategory } from "../entities/subcat.js";
import { Type } from "../entities/type.js";
import { User } from "../entities/user.js";

export const seedDatabase = async () => {
    try {
        console.log("🌱 Seeding started...");

        // 1. GET REPOSITORIES
        const typeRepo = AppDataSource.getRepository(Type);
        const catRepo = AppDataSource.getRepository(Category);
        const subRepo = AppDataSource.getRepository(SubCategory);
        const prodRepo = AppDataSource.getRepository(Product);
        const userRepo = AppDataSource.getRepository(User);

        // 2. CLEAR EXISTING DATA
        // Disable foreign keys so SQLite allows us to wipe tables with relations
        await AppDataSource.query('PRAGMA foreign_keys = OFF');

        // Using .clear() is better than raw SQL because TypeORM 
        // automatically maps to the correct table name for each entity.
        console.log("🧹 Cleaning old data...");
        await prodRepo.clear();
        await subRepo.clear();
        await catRepo.clear();
        await typeRepo.clear();
        await userRepo.clear();

        // Re-enable foreign keys
        await AppDataSource.query('PRAGMA foreign_keys = ON');

        // 3. INSERT TYPES
        console.log("📦 Inserting Types...");
        const electronics = await typeRepo.save(typeRepo.create({ name: 'Electronics' }));
        const clothing = await typeRepo.save(typeRepo.create({ name: 'Clothing' }));
        const home = await typeRepo.save(typeRepo.create({ name: 'Home & Garden' }));

        // 4. INSERT CATEGORIES
        console.log("📂 Inserting Categories...");
        const computers = await catRepo.save(catRepo.create({ name: 'Computers', type: electronics }));
        const mobiles = await catRepo.save(catRepo.create({ name: 'Mobile Phones', type: electronics }));
        const menswear = await catRepo.save(catRepo.create({ name: 'Menswear', type: clothing }));
        const furniture = await catRepo.save(catRepo.create({ name: 'Furniture', type: home }));

        // 5. INSERT SUB-CATEGORIES
        console.log("🏷️ Inserting Sub-Categories...");
        const laptops = await subRepo.save(subRepo.create({ name: 'Laptops', category: computers }));
        const accessories = await subRepo.save(subRepo.create({ name: 'Accessories', category: computers }));
        const smartphones = await subRepo.save(subRepo.create({ name: 'Smartphones', category: mobiles }));
        const sofas = await subRepo.save(subRepo.create({ name: 'Sofas', category: furniture }));

        // 6. INSERT PRODUCTS
        console.log("🛒 Inserting Products...");
        await prodRepo.save([
            { 
                name: 'MacBook Pro 16', 
                description: 'M3 Chip, 16GB RAM', 
                price: 2499, 
                stockQuantity: 10, 
                imagePath: '/ProductImages/placeholder.png', 
                subCategory: laptops 
            },
            { 
                name: 'Logitech MX Master 3', 
                description: 'Wireless Mouse', 
                price: 99, 
                stockQuantity: 50, 
                imagePath: '/ProductImages/placeholder.png', 
                subCategory: accessories 
            }
        ]);

        // 7. INSERT USERS (Password: Password123!)
        console.log("👤 Inserting Users...");
        const hashedPw = '$2b$10$7S3.7N3U6yQWlXF.B8vA1u5N8K.mZ1u4Z.oW2K2vG2vG2vG2vG2vG';
        
        await userRepo.save([
            { 
                name: 'Admin User', 
                email: 'admin@shop.com', 
                password: hashedPw, 
                role: 'Admin', 
                isLocked: false 
            },
            { 
                name: 'John Doe', 
                email: 'customer@test.com', 
                password: hashedPw, 
                role: 'Customer', 
                isLocked: false 
            }
        ]);

        console.log("✅ Seeding complete!");
        
    } catch (error) {
        console.error("❌ Seeding failed:", error);
    }
};