import type { NextFunction, Request, Response } from "express";
import { AppDataSource } from "../../data-source.js";
import { User } from "../entities/user.js";

interface SessionData{
    userId:number,
    role:'Customer'|'Admin'
}

export const sessionStore = new Map<string, SessionData>();
const userRepo = AppDataSource.getRepository(User);

export const authenticate = async(req:Request, res:Response, next: NextFunction) => {
    // session_id -> header 
    // Retrieves session_id from browser
    // Here, sessionId is just a piece of string 
    // const authHeader = req.headers['authorization'];
    // const sessionId = authHeader && authHeader.split(' ')[1];
    const sessionId = req.cookies.session_id;

    // Checks if session exists in memory

    // 'has' is used to check if sessionStore has sessionId or not
    if(!sessionId || !sessionStore.has(sessionId)){
        return res.status(401).json({message:"Unauthorized user. Please log in!"});
    }

    // Here, we retrieve the actual object
    // 'get' actually gets the sessionId from the sessionStore
    // sessionId is used as a reference to retrieve the whole object
    const session = sessionStore.get(sessionId);

    // Finds user with that sessionId
    const user = await userRepo.findOne({
        where: {id:session!.userId},
        select: ['id', 'role', 'isLocked']
    });

    // Checks if user exists or if account is locked
    if (!user || user.isLocked){
        sessionStore.delete(sessionId);
        res.clearCookie('session_id');
        return res.status(403).json({message:"Account is locked or inactive."});
    }

    // Attach verified user's data to request object 
    // It will be passed to authorize function
    (req as any).user = {userId:user.id, role:user.role};

    next();
};

// Checks if user has sufficient permissions -> Admin or Customer
// Role-Based Access Control (RBAC)
export const authorize = (roles:string[]) => {
    return (req:Request, res:Response, next: NextFunction) => {

        // Retrieves data from req object
        const user = (req as any).user;

        // Checks if user's role has enough permissions
        if (!user || !roles.includes(user.role)){
            return res.status(403).json({message:"Insufficient permissions."});
        }
        next();
    };
};