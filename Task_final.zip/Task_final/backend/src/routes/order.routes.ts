import { Router } from "express";
import { OrderController } from "../controllers/order.controller.js";
import { authenticate, authorize } from "../middleware/auth.middleware.js";

const orderRouter = Router();

orderRouter.post("/checkout", authenticate, OrderController.checkout);
orderRouter.get("/my-orders", authenticate, OrderController.getMyOrders);
orderRouter.get("/my-orders/:id", authenticate, OrderController.getOrderDetails);

orderRouter.get("/admin/all", authenticate, authorize(['Admin']), OrderController.getAllOrders);
orderRouter.get("/admin/:id", authenticate, authorize(['Admin']), OrderController.getOrderDetails);

export default orderRouter;