import { Router } from "express";
import { ProductController } from "../controllers/product.controller.js";
import { authenticate, authorize } from "../middleware/auth.middleware.js";

const productRouter = Router();

productRouter.get("/", ProductController.getProducts);
productRouter.get("/:id", ProductController.getProductById);

productRouter.post("/", authenticate, authorize(['Admin']), ProductController.addProduct);
// productRouter.put("/:id", authenticate, authorize(['Admin']), ProductController.updateProduct);
productRouter.delete("/:id", authenticate, authorize(['Admin']), ProductController.deleteProduct);

export default productRouter;