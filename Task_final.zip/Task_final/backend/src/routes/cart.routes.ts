import { Router } from "express";
import { CartController } from "../controllers/cart.controller.js";
import { authenticate } from "../middleware/auth.middleware.js";

const cartRouter = Router();

cartRouter.get("/", authenticate, CartController.getCart);
cartRouter.post("/add", authenticate, CartController.addToCart);
cartRouter.delete("/:id", authenticate, CartController.removeItem);
cartRouter.delete("/clear/all", authenticate, CartController.clearCart);

export default cartRouter;