import { Router } from "express";
import { authenticate, authorize } from "../middleware/auth.middleware.js";
import { UserController } from "../controllers/user.controller.js";

const userRouter = Router();

userRouter.get(
    "/customers", 
    authenticate, 
    authorize(['Admin']), 
    UserController.getAllCustomers
);

userRouter.patch(
    "/customers/:id/lock",
    authenticate,
    authorize(['Admin']),
    UserController.toggleLock
);

userRouter.patch("/updateProfile", authenticate, UserController.updateProfile);

export default userRouter;