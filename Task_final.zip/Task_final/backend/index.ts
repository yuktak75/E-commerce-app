/**
 * This file initializes database, starts the server, ensures DB is ready before server starts and connects routes, middleware, logic together
 */
import "reflect-metadata";
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import winston from 'winston';
import fs from 'fs';
import path from 'path';
import rateLimit from 'express-rate-limit';
import { AppDataSource } from "./data-source.js";
import type {Request, Response, NextFunction} from 'express';

import cookieParser from 'cookie-parser';
import authRouter from './src/routes/auth.routes.js';
import userRouter from './src/routes/user.routes.js';
import cartRouter from './src/routes/cart.routes.js';
import productRouter from './src/routes/product.routes.js';
import orderRouter from './src/routes/order.routes.js';
import { seedDatabase } from './src/seed/seed.js';

// const logger = winston.createLogger({
//     level:'info',
//     format: winston.format.combine(
//         winston.format.timestamp(),
//         winston.format.json()
//     ),
//     transports: [
//         new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
//         new winston.transports.File({ filename: 'logs/combined.log' }),
//         new winston.transports.Console({
//             format: winston.format.combine(
//                 winston.format.colorize(),
//                 winston.format.simple()
//             )
//         })
//     ]
// });

const app = express();
const PORT = 3000;

// ['logs', 'ProductImages'].forEach(dir => {
//     if (!fs.existsSync(dir)) fs.mkdirSync(dir);
// });

// const limiter = rateLimit({
//     windowMs: 15 * 60 * 1000, // 15 minutes
//     // Version 7 uses limit instead of max
//     max: 100, // Limit each IP to 100 requests per window
//     message: "Too many requests, please try again later." 
// });

// app.use(limiter);
app.use(cors({
    origin: "http://localhost:4200", // Angular server
    credentials: true, // set to true for session cookies to work
    methods: ["GET", "POST", "PUT", "DELETE"]
}));

// Morgan -> logging middleware for node.js automatically records every request that hits the server
// Only cares about traffic coming into express server
app.use(morgan('dev'));
app.use(cookieParser());
app.use(express.json());

app.use('/ProductImages', express.static('ProductImages'));

app.use("/api/auth", authRouter);
app.use("/api/user", userRouter);
app.use("/api/cart", cartRouter);
app.use("/api/orders", orderRouter);
app.use("/api/products", productRouter);


// app.use((err: any, req: Request, res: Response, next: NextFunction) => {
//     // Log the error via Winston
//     logger.error(`${err.status || 500} - ${err.message} - ${req.originalUrl} - ${req.method} - ${req.ip}`);
    
//     const status = err.status || 500;
//     const message = err.message || "Internal Server Error";

//     res.status(status).json({
//         success: false,
//         message: message,
//         stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
//     });
// });

AppDataSource.initialize()
    .then(async () => {
        console.log("Data Source has been initialized");

        await seedDatabase();

        app.listen(PORT, () => {
            console.log(`Server running on http://localhost:${PORT}`);
        })
    })
    .catch((err) => {
        console.error("Error during Data Source Initialization", err);
        process.exit(1);
    });

export {app}