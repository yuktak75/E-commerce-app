import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private apiUrl = 'http://localhost:3000/api/products';
  constructor(private http: HttpClient) { }
  
  getProducts(filters:any): Observable<any>{
    let params = new HttpParams();

    Object.keys(filters).forEach(key => {
      if (filters[key]){
        params = params.append(key, filters[key]);
      }
    });
    return this.http.get(this.apiUrl, {params});
  }
  getProductById(id:string):Observable<any>{
    return this.http.get(`${this.apiUrl}/${id}`);
  }

  getTaxonomy(): Observable<any> {
    return this.http.get(`${this.apiUrl}/taxonomy`);
  }
}
