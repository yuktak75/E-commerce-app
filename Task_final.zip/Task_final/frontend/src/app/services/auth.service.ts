import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:3000/api/auth';
  private currentUserSubject = new BehaviorSubject<any>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(private http:HttpClient) {
    this.checkSession().subscribe();
  }

  get currentUserValue() {
    return this.currentUserSubject.value;
  }

  login(credentials:any): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, credentials, {withCredentials: true}).pipe(tap((user:any) => {
      this.currentUserSubject.next(user);
    }));
  }

  checkSession(): Observable<any> {
    return this.http.get(`${this.apiUrl}/me`, {withCredentials:true}).pipe(tap({
      next: (user) => this.currentUserSubject.next(user),
      error: () => this.currentUserSubject.next(null)
    }));
  }

  register(userData: any) {
    return this.http.post(`${this.apiUrl}/register`, userData, {withCredentials:true});
  }

  logout(){
    return this.http.post(`${this.apiUrl}/logout`, {}, {withCredentials: true}).pipe(tap(() => {
      this.currentUserSubject.next(null);
    }))
  }

  isLoggedIn():boolean{
    return !!this.currentUserSubject.value;
  }

  isAdmin():boolean {
    return this.currentUserSubject.value?.role === 'admin';
  }
}