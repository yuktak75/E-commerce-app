import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private apiUrl = 'http://localhost:3000/api/cart';
  private cartItemsSubject = new BehaviorSubject<any[]>([]);
  public cartItems$ = this.cartItemsSubject.asObservable();

  constructor(private http: HttpClient) {}

  // Fetch cart from backend on login or app refresh
  loadCart() {
    return this.http.get<any[]>(this.apiUrl, { withCredentials: true })
      .subscribe(items => this.cartItemsSubject.next(items));
  }

  addToCart(productId: number, quantity: number) {
    return this.http.post(this.apiUrl, { productId, quantity }, { withCredentials: true })
      .pipe(tap(() => this.loadCart())); // Refresh list after adding
  }

  updateQuantity(itemId: number, quantity: number) {
    return this.http.put(`${this.apiUrl}/${itemId}`, { quantity }, { withCredentials: true })
      .pipe(tap(() => this.loadCart()));
  }

  removeFromCart(itemId: number) {
    return this.http.delete(`${this.apiUrl}/${itemId}`, { withCredentials: true })
      .pipe(tap(() => this.loadCart()));
  }

  clearLocalCart() {
    this.cartItemsSubject.next([]);
  }
}
