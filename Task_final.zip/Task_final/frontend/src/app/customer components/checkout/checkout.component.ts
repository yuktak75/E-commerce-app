import { Component } from '@angular/core';

@Component({
  selector: 'app-checkout',
  imports: [],
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css'
})
export class CheckoutComponent {
  // checkout.component.ts
paymentMethods = ['Credit Card', 'Debit Card', 'Cash on Delivery', 'Bank Transfer'];
selectedMethod = '';

placeOrder() {
  const orderData = {
    paymentMethod: this.selectedMethod,
    // The backend already knows the cart items from the session
  };

  this.http.post('http://localhost:3000/api/orders', orderData, { withCredentials: true })
    .subscribe((res: any) => {
      this.cartService.clearLocalCart();
      // Redirect to confirmation page with the order ID
      this.router.navigate(['/payment-confirmation', res.orderId]);
    });
}
}
