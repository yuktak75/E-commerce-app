import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-register',
  imports: [],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  registerForm: FormGroup;
  constructor(private fb:FormBuilder, private authService:AuthService){
    this.registerForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]], 
      password: ['', Validators.required, Validators.minLength(6)]
    });
  }

  onSubmit(){
    if (this.registerForm.valid){
      this.authService.register(this.registerForm.value).subscribe({
        next: (res) => console.log('Registration successful', res),
        error: (err) => console.error('Registration failed', err)
      });
    }
  }
}
