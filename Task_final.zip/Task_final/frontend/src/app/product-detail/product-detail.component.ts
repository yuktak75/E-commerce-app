import { Component } from '@angular/core';

@Component({
  selector: 'app-product-detail',
  imports: [],
  templateUrl: './product-detail.component.html',
  styleUrl: './product-detail.component.css'
})
export class ProductDetailComponent {
  // product-detail.component.ts
shareProduct(product: any) {
  if (navigator.share) {
    navigator.share({
      title: product.name,
      text: `Check out this ${product.name}!`,
      url: window.location.href,
    }).catch(console.error);
  } else {
    // Fallback: Copy to clipboard
    navigator.clipboard.writeText(window.location.href);
    alert('Link copied to clipboard!');
  }
}
}
