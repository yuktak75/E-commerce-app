import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-product-list',
  imports: [],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent implements OnInit{
  products:any[] = [];
  loading = false;

  constructor(
    private route: ActivatedRoute, 
    private productService:ProductService
  ){}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.fetchProducts(params);
    });
  }

  fetchProducts(filters:any){
    this.loading = true;
    this.productService.getProducts(filters).subscribe({
      next: (data) => {
        this.products = data;
        this.loading = false;
      },
      error: (err) => {
        this.loading = false;
        console.error(err);
      }
    })
  }
}
