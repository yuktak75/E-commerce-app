import { Component } from '@angular/core';

@Component({
  selector: 'app-customer-mngmt',
  imports: [],
  templateUrl: './customer-mngmt.component.html',
  styleUrl: './customer-mngmt.component.css'
})
export class CustomerMngmtComponent {

}
