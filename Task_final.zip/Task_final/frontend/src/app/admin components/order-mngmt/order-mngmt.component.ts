import { Component } from '@angular/core';

@Component({
  selector: 'app-order-mngmt',
  imports: [],
  templateUrl: './order-mngmt.component.html',
  styleUrl: './order-mngmt.component.css'
})
export class OrderMngmtComponent {

}
