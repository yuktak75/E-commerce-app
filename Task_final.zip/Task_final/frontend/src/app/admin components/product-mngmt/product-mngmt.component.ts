import { Component } from '@angular/core';

@Component({
  selector: 'app-product-mngmt',
  imports: [],
  templateUrl: './product-mngmt.component.html',
  styleUrl: './product-mngmt.component.css'
})
export class ProductMngmtComponent {

}
